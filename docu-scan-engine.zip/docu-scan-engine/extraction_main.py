"""
Extraction Agent - Main Entry Point

This script runs the extraction workflow to process documents
extracted by the Connection Agent.

Usage:
    python extraction_main.py [--limit 10]

Author: Connection Agent Team
Created: October 26, 2025
"""

import os
import sys
import logging
import argparse
from pathlib import Path

from src.extraction_agent import ExtractionAgent
from src.database_models import DatabaseManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """
    Main entry point for the Extraction Agent workflow
    """
    parser = argparse.ArgumentParser(description='Extraction Agent - OCR and Data Parsing')
    parser.add_argument('--limit', type=int, default=10, 
                       help='Maximum number of documents to process (default: 10)')
    args = parser.parse_args()
    
    print("\n" + "=" * 60)
    print("EXTRACTION AGENT - DOCUMENT DIGITISATION ENGINE")
    print("=" * 60)
    print("OCR and intelligent data parsing for formulation specs")
    print("")
    
    database_url = os.getenv('DATABASE_URL')
    if not database_url:
        logger.error("✗ DATABASE_URL environment variable not set")
        logger.error("Please configure PostgreSQL database connection")
        sys.exit(1)
    
    logger.info("✓ Database URL configured")
    
    try:
        agent = ExtractionAgent()
        
        result = agent.run_extraction_workflow(limit=args.limit)
        
        logger.info("\n[EXTRACTION AGENT] Workflow Summary:")
        logger.info(f"Status: {result['status']}")
        logger.info(f"Documents processed: {result['total_documents']}")
        logger.info(f"Successfully extracted: {result['extracted_count']}")
        logger.info(f"Failed: {result['failed_count']}")
        
        agent.disconnect()
        
        if result['extracted_count'] > 0:
            logger.info("\n✓ Extraction workflow completed successfully")
            logger.info("Documents are now ready for Normalization Agent")
        else:
            logger.info("\n✓ No documents were extracted (none pending or all failed)")
        
    except Exception as e:
        logger.error(f"\n✗ Extraction workflow failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
