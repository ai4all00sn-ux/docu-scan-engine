from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class BaseSourceAdapter(ABC):
    """
    Abstract base class for document source adapters.
    All source adapters must implement these methods.
    """
    
    @abstractmethod
    def authenticate(self) -> bool:
        """
        Authenticate with the document source.
        
        Returns:
            bool: True if authentication successful
        """
        pass
    
    @abstractmethod
    def get_documents_metadata(self, query: Optional[str] = None, limit: int = 10) -> List[Dict]:
        """
        Retrieve document metadata from the source.
        
        Args:
            query: Optional query to filter documents
            limit: Maximum number of documents to retrieve
            
        Returns:
            List of document metadata dictionaries
        """
        pass
    
    @abstractmethod
    def download_document(self, doc_id: str, output_path: str) -> bool:
        """
        Download a document file.
        
        Args:
            doc_id: Document ID
            output_path: Path to save the document
            
        Returns:
            bool: True if download successful
        """
        pass
    
    @abstractmethod
    def get_document_metadata(self, doc_id: str) -> Optional[Dict]:
        """
        Get detailed metadata for a specific document.
        
        Args:
            doc_id: Document ID
            
        Returns:
            Dictionary with document metadata or None
        """
        pass
    
    @abstractmethod
    def extract_keywords(self, metadata: Dict) -> List[str]:
        """
        Extract keywords from document metadata.
        
        Args:
            metadata: Document metadata dictionary
            
        Returns:
            List of extracted keywords
        """
        pass
    
    @abstractmethod
    def disconnect(self) -> bool:
        """
        Disconnect from the document source.
        
        Returns:
            bool: True if disconnect successful
        """
        pass
    
    @abstractmethod
    def get_source_name(self) -> str:
        """
        Get the name of this document source.
        
        Returns:
            Source name
        """
        pass
