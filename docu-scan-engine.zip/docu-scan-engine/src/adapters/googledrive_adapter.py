import os
import logging
import requests
import io
import json
from typing import Dict, Optional, List
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request as GoogleRequest
from google_auth_oauthlib.flow import InstalledAppFlow
from src.base_source_adapter import BaseSourceAdapter

logger = logging.getLogger(__name__)


class GoogleDriveAdapter(BaseSourceAdapter):
    """
    Google Drive adapter for the Connection Agent.
    
    Supports two authentication modes:
    1. Replit Connector (limited to app-created files)
    2. Custom OAuth (full read access with drive.readonly scope)
    """
    
    SCOPES = ['https://www.googleapis.com/auth/drive.readonly']
    TOKEN_FILE = 'token.json'
    
    def __init__(self, config: Dict):
        """
        Initialize the Google Drive adapter.
        
        Args:
            config: Configuration dictionary with keys:
                - folder_name: Name of the folder to connect to (e.g., 'DigitisationEngineSource')
                - folder_id: (Optional) Specific folder ID if known
                - client_id: (Optional) Google OAuth client ID for custom auth
                - client_secret: (Optional) Google OAuth client secret for custom auth
                - use_custom_oauth: (Optional) Force custom OAuth even if Replit connector available
        """
        self.folder_name = config.get('folder_name', '')
        self.folder_id = config.get('folder_id')
        self.client_id = config.get('client_id') or os.getenv('GOOGLE_CLIENT_ID')
        self.client_secret = config.get('client_secret') or os.getenv('GOOGLE_CLIENT_SECRET')
        self.use_custom_oauth = config.get('use_custom_oauth', False)
        self.service = None
        self.access_token = None
        self.credentials = None
        
        if not self.folder_name and not self.folder_id:
            logger.warning("No folder_name or folder_id provided in Google Drive configuration")
    
    def get_source_name(self) -> str:
        return f"Google Drive ({self.folder_name or self.folder_id})"
    
    def _get_replit_access_token(self) -> Optional[str]:
        """Get access token from Replit's Google Drive connector."""
        hostname = os.getenv('REPLIT_CONNECTORS_HOSTNAME')
        x_replit_token = None
        
        repl_identity = os.getenv('REPL_IDENTITY')
        web_repl_renewal = os.getenv('WEB_REPL_RENEWAL')
        
        if repl_identity:
            x_replit_token = 'repl ' + repl_identity
        elif web_repl_renewal:
            x_replit_token = 'depl ' + web_repl_renewal
        
        if not x_replit_token:
            logger.error('Replit identity token not found')
            return None
        
        if not hostname:
            logger.error('REPLIT_CONNECTORS_HOSTNAME not found')
            return None
        
        try:
            url = f'https://{hostname}/api/v2/connection?include_secrets=true&connector_names=google-drive'
            headers = {
                'Accept': 'application/json',
                'X_REPLIT_TOKEN': x_replit_token
            }
            
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            items = data.get('items', [])
            
            if items:
                connection_settings = items[0]
                access_token = (connection_settings.get('settings', {}).get('access_token') or 
                              connection_settings.get('settings', {}).get('oauth', {}).get('credentials', {}).get('access_token'))
                
                if access_token:
                    logger.info("✓ Retrieved access token from Replit connector")
                    return access_token
            
            logger.error("No Google Drive connection found")
            return None
            
        except Exception as e:
            logger.error(f"Error getting access token from Replit: {str(e)}")
            return None
    
    def _authenticate_custom_oauth(self) -> bool:
        """Authenticate using custom OAuth credentials with drive.readonly scope."""
        if not self.client_id or not self.client_secret:
            logger.error("Client ID and Client Secret required for custom OAuth")
            return False
        
        try:
            logger.info("Authenticating with custom OAuth credentials...")
            
            # Try to create credentials from environment variable (production mode)
            refresh_token = os.getenv('GOOGLE_REFRESH_TOKEN')
            if refresh_token and not os.path.exists(self.TOKEN_FILE):
                logger.info("Production mode: Creating credentials from environment variables...")
                token_data = {
                    "refresh_token": refresh_token,
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "scopes": self.SCOPES
                }
                self.credentials = Credentials.from_authorized_user_info(token_data, self.SCOPES)
                logger.info("✓ Credentials created from environment variables")
            # Check if we have a valid token stored (development mode)
            elif os.path.exists(self.TOKEN_FILE):
                logger.info("Found existing token file, attempting to load...")
                with open(self.TOKEN_FILE, 'r') as token_file:
                    token_data = json.load(token_file)
                    self.credentials = Credentials.from_authorized_user_info(token_data, self.SCOPES)
            
            # Refresh token if expired
            if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                logger.info("Token expired, refreshing...")
                self.credentials.refresh(GoogleRequest())
                # Save refreshed token (only in dev where file exists)
                if os.path.exists(self.TOKEN_FILE):
                    with open(self.TOKEN_FILE, 'w') as token_file:
                        token_file.write(self.credentials.to_json())
                logger.info("✓ Token refreshed successfully")
            
            # If no valid credentials, run OAuth flow
            if not self.credentials or not self.credentials.valid:
                logger.info("No valid credentials found, starting OAuth flow...")
                
                # Create client config for InstalledAppFlow
                client_config = {
                    "installed": {
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token",
                        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                        "redirect_uris": ["http://localhost:8080/", "http://localhost"]
                    }
                }
                
                # Set redirect_uri in the flow object
                flow = InstalledAppFlow.from_client_config(
                    client_config, 
                    self.SCOPES,
                    redirect_uri="http://localhost:8080/"
                )
                
                # Use manual code flow (Replit environment doesn't support localhost redirect)
                print("\n" + "="*60)
                print("GOOGLE DRIVE AUTHORIZATION REQUIRED")
                print("="*60)
                print("\nFOLLOW THESE STEPS:\n")
                print("1. Open this URL in your browser:\n")
                
                # Generate authorization URL
                auth_url, _ = flow.authorization_url(
                    prompt='consent',
                    access_type='offline'
                )
                print(f"   {auth_url}\n")
                
                print("2. Sign in and click 'Allow'")
                print("3. After authorization, you'll see a 'site can't be reached' error")
                print("4. DON'T CLOSE THE PAGE! Look at the URL in your browser's address bar")
                print("5. Copy ONLY the code after 'code=' and before '&scope'")
                print("   Example URL: http://localhost:8080/?code=4/0A...xyz&scope=...")
                print("   Copy this part: 4/0A...xyz")
                print("6. Paste the code below\n")
                
                code = input("Enter authorization code: ").strip()
                
                # Exchange code for credentials
                flow.fetch_token(code=code)
                self.credentials = flow.credentials
                
                # Save the credentials for future use
                with open(self.TOKEN_FILE, 'w') as token_file:
                    token_file.write(self.credentials.to_json())
                
                logger.info("✓ OAuth flow completed, credentials saved")
            
            # Build the service
            self.service = build('drive', 'v3', credentials=self.credentials)
            logger.info("✓ Custom OAuth authentication successful")
            return True
            
        except Exception as e:
            logger.error(f"Custom OAuth authentication error: {str(e)}")
            return False
    
    def authenticate(self) -> bool:
        """
        Authenticate with Google Drive.
        
        Tries custom OAuth first (if configured), falls back to Replit connector.
        """
        try:
            # Use custom OAuth if credentials provided or explicitly requested
            if self.client_id and self.client_secret or self.use_custom_oauth:
                logger.info("Using custom OAuth authentication (drive.readonly scope)...")
                if self._authenticate_custom_oauth():
                    # Find folder after authentication
                    if not self.folder_id and self.folder_name:
                        self.folder_id = self._find_folder_by_name(self.folder_name)
                        if self.folder_id:
                            logger.info(f"✓ Found folder '{self.folder_name}' with ID: {self.folder_id}")
                        else:
                            logger.warning(f"Folder '{self.folder_name}' not found in your Drive")
                    return True
                else:
                    logger.warning("Custom OAuth failed, will not fall back to Replit connector")
                    return False
            
            # Fall back to Replit connector
            logger.info("Using Replit connector authentication (limited scope)...")
            
            self.access_token = self._get_replit_access_token()
            
            if not self.access_token:
                logger.error("Failed to get access token from Replit connector")
                logger.info("\n💡 TIP: For full Drive access, set up custom OAuth credentials")
                logger.info("   See GOOGLE_DRIVE_SETUP.md for instructions")
                return False
            
            credentials = Credentials(token=self.access_token)
            self.service = build('drive', 'v3', credentials=credentials)
            
            logger.info(f"✓ Replit connector authentication successful")
            logger.warning("⚠️  Limited to files created by this app (drive.file scope)")
            
            if not self.folder_id and self.folder_name:
                self.folder_id = self._find_folder_by_name(self.folder_name)
                if self.folder_id:
                    logger.info(f"✓ Found folder '{self.folder_name}' with ID: {self.folder_id}")
                else:
                    logger.warning(f"Folder '{self.folder_name}' not found. Will search all accessible files.")
            
            return True
            
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    def _find_folder_by_name(self, folder_name: str) -> Optional[str]:
        """Find a folder by name and return its ID."""
        if not self.service:
            return None
            
        try:
            query = f"name='{folder_name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
            
            results = self.service.files().list(
                q=query,
                spaces='drive',
                fields='files(id, name)',
                pageSize=10
            ).execute()
            
            files = results.get('files', [])
            
            if files:
                return files[0]['id']
            
            return None
            
        except Exception as e:
            logger.error(f"Error finding folder: {str(e)}")
            return None
    
    def _build_query_from_filters(self, filters: Optional[Dict] = None) -> str:
        """
        Build Google Drive query from filter parameters.
        
        Args:
            filters: Dictionary with filter options (name_contains, file_type, modified_after)
        
        Returns:
            Google Drive query string
        """
        conditions = []
        
        if self.folder_id:
            conditions.append(f"'{self.folder_id}' in parents")
        
        conditions.append("trashed=false")
        
        if filters:
            if filters.get('name_contains'):
                keyword = filters['name_contains']
                conditions.append(f"name contains '{keyword}'")
                logger.info(f"Filter: name contains '{keyword}'")
            
            if filters.get('file_type'):
                file_type = filters['file_type'].lower()
                mime_map = {
                    'pdf': 'application/pdf',
                    'doc': 'application/vnd.google-apps.document',
                    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'xls': 'application/vnd.google-apps.spreadsheet',
                    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    'ppt': 'application/vnd.google-apps.presentation',
                    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                    'txt': 'text/plain',
                    'image': 'image/'
                }
                
                if file_type in mime_map:
                    mime_type = mime_map[file_type]
                    if mime_type.endswith('/'):
                        conditions.append(f"mimeType contains '{mime_type}'")
                    else:
                        conditions.append(f"mimeType = '{mime_type}'")
                    logger.info(f"Filter: file type = {file_type}")
            
            if filters.get('modified_after'):
                date = filters['modified_after']
                conditions.append(f"modifiedTime > '{date}T00:00:00'")
                logger.info(f"Filter: modified after {date}")
        
        return " and ".join(conditions)
    
    def get_documents_metadata(self, query: Optional[str] = None, limit: int = 10, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Retrieve document metadata from Google Drive folder.
        
        Args:
            query: Custom Google Drive query (overrides filters)
            limit: Maximum number of documents to retrieve
            filters: Dictionary with filter options (name_contains, file_type, modified_after)
        
        Returns:
            List of document metadata dictionaries
        """
        if not self.service:
            logger.error("Not authenticated. Please authenticate first.")
            return []
        
        try:
            if query:
                drive_query = query
                logger.info(f"Using custom query: {query}")
            else:
                drive_query = self._build_query_from_filters(filters)
                logger.info(f"Built query: {drive_query}")
            
            logger.info(f"Retrieving up to {limit} files from Google Drive...")
            
            results = self.service.files().list(
                q=drive_query,
                spaces='drive',
                fields='files(id, name, mimeType, createdTime, modifiedTime, size, description, webViewLink)',
                pageSize=limit,
                orderBy='modifiedTime desc'
            ).execute()
            
            files = results.get('files', [])
            logger.info(f"✓ Retrieved {len(files)} files")
            
            return files
            
        except Exception as e:
            logger.error(f"Error retrieving documents: {str(e)}")
            return []
    
    def download_document(self, doc_id: str, output_path: str) -> bool:
        """Download a document from Google Drive."""
        if not self.service:
            logger.error("Not authenticated. Please authenticate first.")
            return False
        
        try:
            logger.info(f"Downloading document {doc_id}...")
            
            file_metadata = self.service.files().get(fileId=doc_id, fields='mimeType,name').execute()
            mime_type = file_metadata.get('mimeType', '')
            file_name = file_metadata.get('name', 'unknown')
            
            if mime_type.startswith('application/vnd.google-apps'):
                logger.warning(f"File '{file_name}' is a Google Workspace file ({mime_type}). Exporting as PDF...")
                request = self.service.files().export_media(fileId=doc_id, mimeType='application/pdf')
            else:
                request = self.service.files().get_media(fileId=doc_id)
            
            fh = io.BytesIO()
            downloader = MediaIoBaseDownload(fh, request)
            
            done = False
            while not done:
                status, done = downloader.next_chunk()
                if status:
                    logger.info(f"Download progress: {int(status.progress() * 100)}%")
            
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            fh.seek(0)
            with open(output_path, 'wb') as f:
                f.write(fh.read())
            
            logger.info(f"✓ Downloaded document {doc_id} to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error downloading document {doc_id}: {str(e)}")
            return False
    
    def get_document_metadata(self, doc_id: str) -> Optional[Dict]:
        """Get detailed metadata for a specific document."""
        if not self.service:
            logger.error("Not authenticated. Please authenticate first.")
            return None
        
        try:
            logger.info(f"Retrieving metadata for document {doc_id}...")
            
            metadata = self.service.files().get(
                fileId=doc_id,
                fields='id, name, mimeType, createdTime, modifiedTime, size, description, webViewLink, owners, permissions'
            ).execute()
            
            logger.info(f"✓ Retrieved metadata for document {doc_id}")
            return metadata
            
        except Exception as e:
            logger.error(f"Error retrieving metadata for document {doc_id}: {str(e)}")
            return None
    
    def extract_keywords(self, metadata: Dict) -> List[str]:
        """Extract keywords from document metadata."""
        keywords = []
        
        name = metadata.get('name', '')
        if name:
            keywords.append(name)
        
        description = metadata.get('description', '')
        if description:
            keywords.extend(description.split())
        
        mime_type = metadata.get('mimeType', '')
        if mime_type:
            if 'pdf' in mime_type.lower():
                keywords.append('PDF')
            elif 'document' in mime_type.lower():
                keywords.append('Document')
            elif 'spreadsheet' in mime_type.lower():
                keywords.append('Spreadsheet')
            elif 'presentation' in mime_type.lower():
                keywords.append('Presentation')
        
        owners = metadata.get('owners', [])
        for owner in owners:
            owner_name = owner.get('displayName')
            if owner_name:
                keywords.append(f"Owner:{owner_name}")
        
        return list(set(keywords))
    
    def disconnect(self) -> bool:
        """Disconnect from Google Drive."""
        logger.info("✓ Disconnected from Google Drive")
        self.service = None
        self.access_token = None
        return True
