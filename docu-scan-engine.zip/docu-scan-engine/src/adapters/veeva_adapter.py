import requests
import logging
from typing import Dict, Optional, List
from src.base_source_adapter import BaseSourceAdapter

logger = logging.getLogger(__name__)


class VeevaVaultAdapter(BaseSourceAdapter):
    """
    Veeva Vault adapter for the Connection Agent.
    Implements secure connection to Veeva Quality Documentation Vault.
    """
    
    def __init__(self, config: Dict):
        """
        Initialize the Veeva Vault adapter.
        
        Args:
            config: Configuration dictionary with keys:
                - vault_dns: Vault DNS
                - username: Username
                - password: Password
                - api_version: API version (optional, default: v25.2)
        """
        self.vault_dns = config.get('vault_dns', '')
        self.username = config.get('username', '')
        self.password = config.get('password', '')
        self.api_version = config.get('api_version', 'v25.2')
        self.base_url = f"https://{self.vault_dns}/api/{self.api_version}"
        self.session_id: Optional[str] = None
        
        if not self.vault_dns or not self.username or not self.password:
            logger.warning("Incomplete Veeva configuration")
    
    def get_source_name(self) -> str:
        return f"Veeva Vault ({self.vault_dns})"
    
    def authenticate(self) -> bool:
        """Authenticate with Veeva Vault and obtain a session ID."""
        auth_url = f"{self.base_url}/auth"
        
        data = {
            "username": self.username,
            "password": self.password
        }
        
        try:
            logger.info(f"Authenticating with Veeva Vault at {self.vault_dns}...")
            response = requests.post(auth_url, data=data)
            response.raise_for_status()
            
            result = response.json()
            
            if result.get("responseStatus") == "SUCCESS":
                self.session_id = result.get("sessionId")
                logger.info(f"✓ Authentication successful with {self.get_source_name()}")
                return True
            else:
                logger.error(f"Authentication failed: {result}")
                return False
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Authentication error: {str(e)}")
            return False
    
    def _get_headers(self) -> Dict[str, str]:
        """Get headers with session authentication."""
        if not self.session_id:
            raise ValueError("Not authenticated. Call authenticate() first.")
        
        return {
            "Authorization": self.session_id,
            "Accept": "application/json"
        }
    
    def get_documents_metadata(self, query: Optional[str] = None, limit: int = 10, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Retrieve document metadata from Veeva Vault.
        
        Args:
            query: Custom VQL query
            limit: Maximum number of documents
            filters: Not used for Veeva (reserved for future use)
        """
        if not self.session_id:
            logger.error("Not authenticated. Please authenticate first.")
            return []
        
        try:
            vql_url = f"{self.base_url}/query"
            
            if query:
                params = {"q": query}
                logger.info(f"Executing custom VQL query: {query}")
            else:
                params = {"q": f"SELECT id, name__v, type__v, subtype__v, classification__v, lifecycle__v, status__v, version_id FROM documents MAXROWS {limit}"}
                logger.info(f"Retrieving {limit} documents...")
            
            response = requests.get(vql_url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            result = response.json()
            
            if result.get("responseStatus") == "SUCCESS":
                documents = result.get("data", [])
                logger.info(f"✓ Retrieved {len(documents)} documents")
                return documents
            else:
                logger.error(f"Failed to retrieve documents: {result}")
                return []
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error retrieving documents: {str(e)}")
            return []
    
    def download_document(self, doc_id: str, output_path: str) -> bool:
        """Download a document's PDF file."""
        if not self.session_id:
            logger.error("Not authenticated. Please authenticate first.")
            return False
        
        download_url = f"{self.base_url}/objects/documents/{doc_id}/file"
        
        try:
            logger.info(f"Downloading document {doc_id}...")
            response = requests.get(download_url, headers=self._get_headers(), stream=True)
            response.raise_for_status()
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"✓ Downloaded document {doc_id} to {output_path}")
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error downloading document {doc_id}: {str(e)}")
            return False
    
    def get_document_metadata(self, doc_id: str) -> Optional[Dict]:
        """Get detailed metadata for a specific document."""
        if not self.session_id:
            logger.error("Not authenticated. Please authenticate first.")
            return None
        
        metadata_url = f"{self.base_url}/objects/documents/{doc_id}"
        
        try:
            logger.info(f"Retrieving metadata for document {doc_id}...")
            response = requests.get(metadata_url, headers=self._get_headers())
            response.raise_for_status()
            
            result = response.json()
            
            if result.get("responseStatus") == "SUCCESS":
                metadata = result.get("document", {})
                logger.info(f"✓ Retrieved metadata for document {doc_id}")
                return metadata
            else:
                logger.error(f"Failed to retrieve metadata: {result}")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error retrieving metadata for document {doc_id}: {str(e)}")
            return None
    
    def extract_keywords(self, metadata: Dict) -> List[str]:
        """Extract keywords from document metadata."""
        keywords = []
        
        keyword_fields = [
            'keywords__v',
            'tags__v', 
            'product__v',
            'therapeutic_area__v',
            'classification__v',
            'subtype__v',
            'type__v'
        ]
        
        for field in keyword_fields:
            value = metadata.get(field)
            if value:
                if isinstance(value, list):
                    keywords.extend(value)
                else:
                    keywords.append(str(value))
        
        return list(set(keywords))
    
    def disconnect(self) -> bool:
        """End the current session."""
        if not self.session_id:
            return True
        
        logout_url = f"{self.base_url}/auth"
        
        try:
            response = requests.delete(logout_url, headers=self._get_headers())
            response.raise_for_status()
            
            logger.info("✓ Disconnected from Veeva Vault")
            self.session_id = None
            return True
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error during disconnect: {str(e)}")
            return False
