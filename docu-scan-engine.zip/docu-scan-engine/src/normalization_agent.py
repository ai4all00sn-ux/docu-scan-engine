"""
Normalization Agent - Entity Extraction and ERD Creation
Parses extracted text and creates structured ERD entities (SKU, raw materials, suppliers)
"""

import os
import re
import logging
from typing import List, Dict, Optional
from datetime import datetime
from pathlib import Path

from src.database_models import DatabaseManager, Document, ERDEntity, AuditTrail, MasterRawMaterial, ProductRawMaterialComposition

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class NormalizationAgent:
    """
    Normalization Agent for intelligent entity extraction
    Reads documents with status 'Data Extracted' and creates ERD entities
    """
    
    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        """
        Initialize the Normalization Agent
        
        Args:
            db_manager: DatabaseManager instance (optional, will create if None)
        """
        self.db_manager = db_manager
        if self.db_manager is None:
            database_url = os.getenv('DATABASE_URL')
            if database_url:
                self.db_manager = DatabaseManager(database_url)
                logger.info("✓ Database manager initialized for normalization agent")
            else:
                raise ValueError("DATABASE_URL environment variable not set")
        
        self.normalized_count = 0
        self.failed_count = 0
        
    def get_extracted_documents(self, limit: int = 10) -> List[Document]:
        """
        Retrieve documents from database with status 'Data Extracted'
        
        Args:
            limit: Maximum number of documents to process
            
        Returns:
            List of Document objects
        """
        logger.info(f"\n[NORMALIZATION AGENT] Querying database for extracted documents (limit: {limit})...")
        
        session = self.db_manager.get_session()
        try:
            documents = session.query(Document).filter(
                Document.processing_status == "Data Extracted"
            ).limit(limit).all()
            
            logger.info(f"✓ Found {len(documents)} documents ready for normalization")
            return documents
            
        except Exception as e:
            logger.error(f"Error querying database: {str(e)}")
            return []
        finally:
            session.close()
    
    def extract_product_entity(self, extracted_text: str, document_id: str) -> Optional[Dict]:
        """
        Extract product/SKU entity from text
        
        Args:
            extracted_text: OCR extracted text
            document_id: Document ID
            
        Returns:
            Product entity dict or None
        """
        product_entity = None
        
        pid_match = re.search(r'(?:Product\s+Identifier\s*\(?PID\)?|PID)[\s:]+([A-Z]+-\d+)', extracted_text, re.IGNORECASE)
        if pid_match:
            pid = pid_match.group(1)
            
            product_name_match = re.search(r'Product\s+Name[\s:]+([^\n]+)', extracted_text, re.IGNORECASE)
            product_name = product_name_match.group(1).strip() if product_name_match else None
            
            dosage_form_match = re.search(r'Dosage\s+Form[\s:]+([^\n]+)', extracted_text, re.IGNORECASE)
            dosage_form = dosage_form_match.group(1).strip() if dosage_form_match else None
            
            version_match = re.search(r'Version[\s:]+([^\n]+)', extracted_text, re.IGNORECASE)
            version = version_match.group(1).strip() if version_match else None
            
            product_entity = {
                'entity_type': 'SKU/PRODUCT',
                'primary_key': pid,
                'entity_data': {
                    'pid': pid,
                    'product_name': product_name,
                    'dosage_form': dosage_form,
                    'version': version,
                    'document_id': document_id
                },
                'extraction_confidence': 95.0
            }
            logger.info(f"✓ Extracted product entity: {pid} - {product_name}")
        
        return product_entity
    
    def extract_ingredient_entities(self, extracted_text: str, document_id: str) -> List[Dict]:
        """
        Extract raw material/ingredient entities from ingredient table
        Handles both single-line and multi-line table formats
        
        Args:
            extracted_text: OCR extracted text
            document_id: Document ID
            
        Returns:
            List of ingredient entity dicts
        """
        ingredients = []
        
        rmc_pattern = r'\[?(RMC-\d{3})\]?'
        lines = extracted_text.split('\n')
        in_composition_section = False
        skip_until = -1
        
        for i, line in enumerate(lines):
            if i < skip_until:
                continue
                
            if re.search(r'Qualitative\s+and\s+Quantitative\s+Composition', line, re.IGNORECASE):
                in_composition_section = True
                continue
            
            if in_composition_section and re.search(r'^\d+\.', line):
                in_composition_section = False
                break
            
            if in_composition_section and re.search(rmc_pattern, line):
                rmc_match = re.search(rmc_pattern, line)
                if rmc_match:
                    rmc_code = rmc_match.group(1)
                    
                    ingredient_name = None
                    name_match = re.search(r'([A-Z][a-zA-Z\s]+?)\s*\[?RMC-\d{3}\]?', line)
                    if name_match:
                        ingredient_name = name_match.group(1).strip()
                    
                    function = None
                    quantity = None
                    lines_consumed = 0
                    
                    if i + 1 < len(lines):
                        next_line = lines[i + 1].strip()
                        if next_line and not re.search(rmc_pattern, next_line) and not re.search(r'^\d+\.', next_line):
                            if not re.match(r'^[\d.]+$', next_line) and not re.match(r'^q\.s\.', next_line, re.IGNORECASE):
                                function = next_line
                                lines_consumed = 1
                    
                    if i + 2 < len(lines) and lines_consumed == 1:
                        qty_line = lines[i + 2].strip()
                        if qty_line and not re.search(rmc_pattern, qty_line):
                            if re.match(r'^[\d.]+$', qty_line) or re.match(r'^q\.s\.', qty_line, re.IGNORECASE):
                                quantity = qty_line
                                lines_consumed = 2
                    
                    if not function or not quantity:
                        parts = re.split(r'\s{2,}|\t', line)
                        for j, part in enumerate(parts):
                            part = part.strip()
                            if not function and j > 0 and part and not re.search(rmc_pattern, part):
                                if not re.match(r'^[\d.]+$', part) and not re.match(r'^q\.s\.', part, re.IGNORECASE):
                                    if part not in ['Function', 'Quantity', 'Component']:
                                        function = part
                            
                            if not quantity and (re.match(r'^[\d.]+$', part) or re.match(r'^q\.s\.', part, re.IGNORECASE)):
                                quantity = part
                    
                    if lines_consumed > 0:
                        skip_until = i + lines_consumed + 1
                    
                    confidence = 90.0 if (ingredient_name and function and quantity) else (80.0 if (ingredient_name and function) else 70.0)
                    
                    ingredient_entity = {
                        'entity_type': 'raw_material',
                        'primary_key': rmc_code,
                        'entity_data': {
                            'rmc_code': rmc_code,
                            'ingredient_name': ingredient_name,
                            'function': function,
                            'quantity': quantity,
                            'document_id': document_id
                        },
                        'extraction_confidence': confidence
                    }
                    
                    ingredients.append(ingredient_entity)
                    logger.info(f"  → Ingredient: {rmc_code} - {ingredient_name} | {function} | {quantity}")
        
        logger.info(f"✓ Extracted {len(ingredients)} ingredient entities")
        return ingredients
    
    def extract_supplier_entities(self, extracted_text: str, document_id: str) -> List[Dict]:
        """
        Extract supplier entities from text
        
        Args:
            extracted_text: OCR extracted text
            document_id: Document ID
            
        Returns:
            List of supplier entity dicts
        """
        suppliers = []
        
        supplier_patterns = [
            r'Supplier[\s:]+([A-Z][A-Za-z\s&]+(?:Ltd|Inc|Corp|GmbH|Co\.))',
            r'Manufacturer[\s:]+([A-Z][A-Za-z\s&]+(?:Ltd|Inc|Corp|GmbH|Co\.))',
            r'Vendor[\s:]+([A-Z][A-Za-z\s&]+(?:Ltd|Inc|Corp|GmbH|Co\.))'
        ]
        
        for pattern in supplier_patterns:
            matches = re.finditer(pattern, extracted_text, re.IGNORECASE)
            for match in matches:
                supplier_name = match.group(1).strip()
                
                supplier_entity = {
                    'entity_type': 'supplier',
                    'primary_key': supplier_name,
                    'entity_data': {
                        'supplier_name': supplier_name,
                        'document_id': document_id
                    },
                    'extraction_confidence': 75.0
                }
                
                suppliers.append(supplier_entity)
                logger.info(f"  → Supplier: {supplier_name}")
        
        if suppliers:
            logger.info(f"✓ Extracted {len(suppliers)} supplier entities")
        
        return suppliers
    
    def _create_or_get_master_raw_material(self, session, ingredient_name: str) -> Optional[MasterRawMaterial]:
        """
        Create or retrieve master raw material by ingredient name (deduplication)
        
        Args:
            session: Database session
            ingredient_name: Ingredient name
            
        Returns:
            MasterRawMaterial object or None
        """
        if not ingredient_name or not ingredient_name.strip():
            return None
        
        ingredient_name = ingredient_name.strip()
        
        existing = session.query(MasterRawMaterial).filter(
            MasterRawMaterial.ingredient_name == ingredient_name
        ).first()
        
        if existing:
            return existing
        
        new_material = MasterRawMaterial(
            ingredient_name=ingredient_name,
            enterprise_erp_id=None
        )
        session.add(new_material)
        session.flush()
        
        return new_material
    
    def normalize_document(self, document: Document) -> bool:
        """
        Normalize a single document by extracting entities
        
        Args:
            document: Document object from database
            
        Returns:
            True if successful, False otherwise
        """
        logger.info(f"\n[NORMALIZATION AGENT] Processing document: {document.document_name}")
        logger.info(f"Document ID: {document.document_id}")
        
        try:
            extracted_text = document.raw_metadata.get('extracted_text', '')
            
            if not extracted_text:
                logger.error("No extracted text found in document metadata")
                self._log_audit(document.document_id, "entity_extraction", "error", 
                              "No extracted text in metadata")
                return False
            
            logger.info("Extracting entities from document...")
            
            all_entities = []
            
            product_entity = self.extract_product_entity(extracted_text, document.document_id)
            if product_entity:
                all_entities.append(product_entity)
            
            ingredient_entities = self.extract_ingredient_entities(extracted_text, document.document_id)
            all_entities.extend(ingredient_entities)
            
            supplier_entities = self.extract_supplier_entities(extracted_text, document.document_id)
            all_entities.extend(supplier_entities)
            
            if not all_entities:
                logger.warning("No entities extracted from document")
                self._log_audit(document.document_id, "entity_extraction", "error", 
                              "No entities could be extracted")
                return False
            
            session = self.db_manager.get_session()
            try:
                product_entity_id = None
                raw_materials_created = 0
                compositions_created = 0
                
                for entity_data in all_entities:
                    entity = ERDEntity(
                        document_id=document.document_id,
                        entity_type=entity_data['entity_type'],
                        primary_key=entity_data['primary_key'],
                        entity_data=entity_data['entity_data'],
                        extraction_confidence=entity_data['extraction_confidence'],
                        extracted_by='normalization_agent'
                    )
                    session.add(entity)
                    session.flush()
                    
                    if entity_data['entity_type'] == 'SKU/PRODUCT':
                        product_entity_id = entity.entity_id
                    
                    if entity_data['entity_type'] == 'raw_material' and product_entity_id:
                        ingredient_name = entity_data['entity_data'].get('ingredient_name')
                        
                        if ingredient_name and ingredient_name.strip():
                            master_material = self._create_or_get_master_raw_material(session, ingredient_name)
                            
                            if master_material:
                                composition = ProductRawMaterialComposition(
                                    product_entity_id=product_entity_id,
                                    raw_material_id=master_material.raw_material_id,
                                    document_id=document.document_id,
                                    document_rmc_code=entity_data['entity_data'].get('rmc_code'),
                                    quantity=entity_data['entity_data'].get('quantity'),
                                    function=entity_data['entity_data'].get('function'),
                                    extraction_confidence=entity_data['extraction_confidence']
                                )
                                session.add(composition)
                                compositions_created += 1
                                raw_materials_created += 1
                
                db_document = session.query(Document).filter(
                    Document.document_id == document.document_id
                ).first()
                
                if db_document:
                    db_document.processing_status = "Normalized"
                    db_document.processed_at = datetime.now()
                
                session.commit()
                logger.info(f"✓ Saved {len(all_entities)} entities to database")
                if compositions_created > 0:
                    logger.info(f"✓ Created {compositions_created} product-raw material compositions")
                logger.info(f"✓ Updated document status to 'Normalized'")
                
            finally:
                session.close()
            
            self._log_audit(document.document_id, "entity_extraction", "success", 
                          f"Extracted {len(all_entities)} entities (Product: {1 if product_entity else 0}, Ingredients: {len(ingredient_entities)}, Suppliers: {len(supplier_entities)})")
            
            self.normalized_count += 1
            return True
            
        except Exception as e:
            logger.error(f"Normalization failed: {str(e)}")
            self._log_audit(document.document_id, "entity_extraction", "error", str(e))
            self.failed_count += 1
            return False
    
    def _log_audit(self, document_id: str, action: str, status: str, error_message: str = ""):
        """
        Log action to audit trail
        
        Args:
            document_id: Document ID
            action: Action performed
            status: Action status (success, error, skipped)
            error_message: Error message if applicable
        """
        session = self.db_manager.get_session()
        try:
            audit = AuditTrail(
                document_id=document_id,
                agent_name="normalization_agent",
                action=action,
                status=status,
                error_message=error_message if status == "error" else None,
                action_details={"timestamp": datetime.now().isoformat()} if status != "error" else {"error": error_message}
            )
            session.add(audit)
            session.commit()
        except Exception as e:
            logger.error(f"Audit logging failed: {str(e)}")
        finally:
            session.close()
    
    def run_normalization_workflow(self, limit: int = 10) -> Dict:
        """
        Run the complete normalization workflow
        
        Args:
            limit: Maximum number of documents to process
            
        Returns:
            Summary dictionary
        """
        logger.info("\n" + "=" * 60)
        logger.info("NORMALIZATION AGENT - ENTITY EXTRACTION WORKFLOW")
        logger.info("=" * 60)
        
        documents = self.get_extracted_documents(limit)
        
        if not documents:
            logger.info("No documents ready for normalization.")
            return {
                "status": "completed",
                "normalized_count": 0,
                "failed_count": 0,
                "message": "No documents with status 'Data Extracted'"
            }
        
        logger.info(f"\n[NORMALIZATION AGENT] Processing {len(documents)} documents...")
        
        for i, document in enumerate(documents, 1):
            logger.info(f"\nProcessing document {i}/{len(documents)}...")
            self.normalize_document(document)
        
        logger.info("\n" + "=" * 60)
        logger.info("NORMALIZATION WORKFLOW COMPLETED")
        logger.info("=" * 60)
        logger.info(f"✓ Successfully normalized: {self.normalized_count} documents")
        logger.info(f"✗ Failed: {self.failed_count} documents")
        logger.info("=" * 60)
        
        return {
            "status": "completed",
            "normalized_count": self.normalized_count,
            "failed_count": self.failed_count,
            "total_processed": len(documents)
        }
