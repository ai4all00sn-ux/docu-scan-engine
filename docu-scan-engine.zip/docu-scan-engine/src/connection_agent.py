import logging
import os
from typing import Dict, List, Optional
from src.base_source_adapter import BaseSourceAdapter
from src.adapters.veeva_adapter import VeevaVaultAdapter
from src.adapters.googledrive_adapter import GoogleDriveAdapter
from src.document_processor import DocumentProcessor
from src.config_manager import ConfigManager

logger = logging.getLogger(__name__)


class ConnectionAgent:
    """
    Intelligent Connection Agent for document digitisation.
    Supports multiple document sources through pluggable adapters.
    Integrates with PostgreSQL database for multi-agent pipeline.
    """
    
    ADAPTER_MAP = {
        'veeva': VeevaVaultAdapter,
        'googledrive': GoogleDriveAdapter,
    }
    
    def __init__(self, config_file: Optional[str] = None, db_manager=None):
        """
        Initialize the Connection Agent.
        
        Args:
            config_file: Path to job configuration file (optional)
            db_manager: DatabaseManager instance for PostgreSQL integration (optional)
        """
        self.config_manager = ConfigManager(config_file)
        self.adapter: Optional[BaseSourceAdapter] = None
        self.db_manager = db_manager
        self.processor = None  # Will be initialized when we know the source
        self.is_connected = False
        self.current_source = None
    
    def connect_from_config(self, source_name: Optional[str] = None) -> bool:
        """
        Connect to a source using job configuration file.
        
        Args:
            source_name: Name of source to connect to (uses default if not provided)
            
        Returns:
            bool: True if connection successful
        """
        source_config = self.config_manager.get_source_config(source_name)
        
        if not source_config:
            logger.error(f"No configuration found for source: {source_name or 'default'}")
            return False
        
        return self._connect_with_config(source_config)
    
    def connect_from_env(self, source_type: str) -> bool:
        """
        Connect to a source using environment variables.
        
        Args:
            source_type: Type of source (e.g., 'veeva')
            
        Returns:
            bool: True if connection successful
        """
        source_config = self.config_manager.load_from_env(source_type)
        return self._connect_with_config(source_config)
    
    def connect_direct(self, source_type: str, connection_params: Dict) -> bool:
        """
        Connect to a source with directly provided parameters.
        
        Args:
            source_type: Type of source (e.g., 'veeva')
            connection_params: Connection parameters dictionary
            
        Returns:
            bool: True if connection successful
        """
        source_config = {"source_type": source_type}
        source_config.update(connection_params)
        return self._connect_with_config(source_config)
    
    def _connect_with_config(self, source_config: Dict) -> bool:
        """
        Internal method to connect with a configuration dictionary.
        
        Args:
            source_config: Source configuration
            
        Returns:
            bool: True if connection successful
        """
        source_type = source_config.get('source_type')
        
        if not source_type:
            logger.error("No source_type specified in configuration")
            return False
        
        adapter_class = self.ADAPTER_MAP.get(source_type)
        
        if not adapter_class:
            logger.error(f"Unknown source type: {source_type}")
            logger.info(f"Available source types: {', '.join(self.ADAPTER_MAP.keys())}")
            return False
        
        logger.info(f"\n[CONNECTION AGENT] Initializing {source_type} adapter...")
        self.adapter = adapter_class(source_config)
        self.current_source = source_type
        
        # Initialize DocumentProcessor with database manager and source system
        self.processor = DocumentProcessor(
            output_dir="downloads",
            db_manager=self.db_manager,
            source_system=source_type
        )
        
        logger.info(f"[CONNECTION AGENT] Authenticating with {self.adapter.get_source_name()}...")
        self.is_connected = self.adapter.authenticate()
        
        return self.is_connected
    
    def discover_documents(self, query: Optional[str] = None, limit: int = 10, filters: Optional[Dict] = None) -> List[Dict]:
        """
        Discover documents from the connected source.
        
        Args:
            query: Optional query to filter documents (overrides filters)
            limit: Maximum number of documents to retrieve
            filters: Dictionary with filter options (name_contains, file_type, modified_after)
            
        Returns:
            List of document metadata
        """
        if not self.is_connected or not self.adapter:
            logger.error("Not connected to any source. Please connect first.")
            return []
        
        logger.info(f"\n[CONNECTION AGENT] Discovering documents from {self.adapter.get_source_name()}...")
        
        if not hasattr(self.adapter, 'get_documents_metadata'):
            return []
        
        try:
            return self.adapter.get_documents_metadata(query=query, limit=limit, filters=filters)
        except TypeError:
            return self.adapter.get_documents_metadata(query=query, limit=limit)
    
    def extract_document(self, doc_id: str, download_file: bool = True) -> Optional[Dict]:
        """
        Extract a single document with metadata and keywords.
        
        Args:
            doc_id: Document ID to extract
            download_file: Whether to download the document file
            
        Returns:
            Processed document data or None
        """
        if not self.is_connected or not self.adapter:
            logger.error("Not connected to any source. Please connect first.")
            return None
        
        logger.info(f"\n[CONNECTION AGENT] Extracting document {doc_id}...")
        
        metadata = self.adapter.get_document_metadata(doc_id)
        if not metadata:
            logger.error(f"Failed to retrieve metadata for document {doc_id}")
            return None
        
        keywords = self.adapter.extract_keywords(metadata)
        logger.info(f"✓ Extracted {len(keywords)} keywords")
        
        file_path = None
        if download_file:
            file_path = self.processor.get_pdf_path(doc_id)
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            success = self.adapter.download_document(doc_id, file_path)
            if not success:
                file_path = None
        
        processed_doc = self.processor.process_document(doc_id, metadata, keywords, file_path)
        return processed_doc
    
    def batch_extract(self, doc_ids: List[str], download_files: bool = True) -> List[Dict]:
        """
        Batch extract multiple documents.
        
        Args:
            doc_ids: List of document IDs to extract
            download_files: Whether to download document files
            
        Returns:
            List of processed documents
        """
        logger.info(f"\n[CONNECTION AGENT] Batch extracting {len(doc_ids)} documents...")
        
        results = []
        for i, doc_id in enumerate(doc_ids, 1):
            logger.info(f"\nProcessing document {i}/{len(doc_ids)}...")
            result = self.extract_document(doc_id, download_files)
            if result:
                results.append(result)
        
        return results
    
    def generate_report(self) -> str:
        """
        Generate processing report.
        
        Returns:
            Formatted report string
        """
        logger.info("\n[CONNECTION AGENT] Generating digitisation report...")
        return self.processor.generate_report()
    
    def disconnect(self) -> bool:
        """
        Disconnect from the current source and close database connections.
        
        Returns:
            bool: True if disconnect successful
        """
        if self.processor:
            self.processor.close()
        
        if self.adapter:
            success = self.adapter.disconnect()
            self.is_connected = False
            return success
        return True
    
    def run_workflow(self, query: Optional[str] = None, limit: int = 10, 
                    download_files: bool = True, filters: Optional[Dict] = None) -> Dict:
        """
        Execute the complete document extraction workflow.
        
        Args:
            query: Optional query to filter documents (overrides filters)
            limit: Maximum number of documents to process
            download_files: Whether to download document files
            filters: Dictionary with filter options (name_contains, file_type, modified_after)
            
        Returns:
            Workflow results dictionary
        """
        logger.info("\n" + "="*60)
        logger.info("CONNECTION AGENT - DOCUMENT DIGITISATION WORKFLOW")
        logger.info("="*60)
        
        if not self.is_connected:
            logger.error("Not connected. Workflow aborted.")
            return {"success": False, "error": "Not connected to any source"}
        
        documents = self.discover_documents(query, limit, filters)
        if not documents:
            logger.warning("No documents found. Workflow completed with no results.")
            return {"success": True, "documents_processed": 0, "message": "No documents found"}
        
        doc_ids = [str(doc.get("id")) for doc in documents if doc.get("id") is not None]
        
        results = self.batch_extract(doc_ids, download_files)
        
        report = self.generate_report()
        print(report)
        
        self.processor.export_to_csv()
        
        self.disconnect()
        
        logger.info("\n" + "="*60)
        logger.info("WORKFLOW COMPLETED SUCCESSFULLY")
        logger.info("="*60)
        
        return {
            "success": True,
            "source": self.current_source,
            "documents_discovered": len(documents),
            "documents_processed": len(results),
            "output_directory": self.processor.output_dir,
            "report": report
        }
