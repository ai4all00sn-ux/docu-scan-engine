"""
Database Models for Agentic Digitization Engine

This module defines SQLAlchemy ORM models for the multi-agent pipeline:
- Connection Agent: Writes to documents table
- Normalisation Agent: Writes to erd_entities table
- Qualification Agent: Writes to validation_results table
- Validation/Update Agent: Writes to user_feedback table
- All Agents: Write to audit_trail table
"""

from sqlalchemy import create_engine, Column, String, Integer, DECIMAL, Boolean, Text, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy.sql import func
from datetime import datetime
import os
import uuid

Base = declarative_base()


class Document(Base):
    """
    Documents table - Connection Agent writes extracted documents here
    This is the foundation table that all other agents reference
    """
    __tablename__ = 'documents'
    
    document_id = Column(String(255), primary_key=True)
    company_document_id = Column(String(255))
    document_name = Column(String(500))
    document_version = Column(String(100))
    processing_status = Column(String(100), default='Extracted - Not Processed')
    document_type = Column(String(100))
    document_subtype = Column(String(100))
    classification = Column(String(100))
    lifecycle = Column(String(100))
    status = Column(String(100))
    keywords = Column(Text)
    pdf_path = Column(String(1000))
    source_system = Column(String(100))
    extracted_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime)
    raw_metadata = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    erd_entities = relationship('ERDEntity', back_populates='document', cascade='all, delete-orphan')
    validation_results = relationship('ValidationResult', back_populates='document', cascade='all, delete-orphan')
    user_feedback = relationship('UserFeedback', back_populates='document', cascade='all, delete-orphan')
    audit_trail = relationship('AuditTrail', back_populates='document', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<Document(id={self.document_id}, name={self.document_name}, status={self.processing_status})>"


class ERDEntity(Base):
    """
    ERD Entities table - Normalisation Agent writes extracted entities here
    Entity types: SKU/PRODUCT, raw_material, supplier, mfg_site, country_regulator
    """
    __tablename__ = 'erd_entities'
    
    entity_id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(String(255), ForeignKey('documents.document_id', ondelete='CASCADE'))
    entity_type = Column(String(100), nullable=False)
    primary_key = Column(String(255))
    entity_data = Column(JSON)
    extraction_confidence = Column(DECIMAL(5, 2))
    extracted_by = Column(String(100), default='normalisation_agent')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    document = relationship('Document', back_populates='erd_entities')
    validation_results = relationship('ValidationResult', back_populates='entity', cascade='all, delete-orphan')
    user_feedback = relationship('UserFeedback', back_populates='entity', cascade='all, delete-orphan')
    audit_trail = relationship('AuditTrail', back_populates='entity', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<ERDEntity(id={self.entity_id}, type={self.entity_type}, doc={self.document_id})>"


class ValidationResult(Base):
    """
    Validation Results table - Qualification Agent writes validation results here
    Tracks structural and value normalization/qualification
    """
    __tablename__ = 'validation_results'
    
    validation_id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('erd_entities.entity_id', ondelete='CASCADE'))
    document_id = Column(String(255), ForeignKey('documents.document_id', ondelete='CASCADE'))
    qualification_status = Column(String(100))
    structural_match = Column(Boolean)
    value_match = Column(Boolean)
    confidence_score = Column(DECIMAL(5, 2))
    sap_pim_reference = Column(String(255))
    mismatch_details = Column(JSON)
    validated_by = Column(String(100), default='qualification_agent')
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    entity = relationship('ERDEntity', back_populates='validation_results')
    document = relationship('Document', back_populates='validation_results')
    user_feedback = relationship('UserFeedback', back_populates='validation', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<ValidationResult(id={self.validation_id}, status={self.qualification_status})>"


class UserFeedback(Base):
    """
    User Feedback table - Validation/Update Agent writes user actions here
    Captures user approvals, corrections, and rejections
    """
    __tablename__ = 'user_feedback'
    
    feedback_id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('erd_entities.entity_id', ondelete='CASCADE'))
    document_id = Column(String(255), ForeignKey('documents.document_id', ondelete='CASCADE'))
    validation_id = Column(Integer, ForeignKey('validation_results.validation_id', ondelete='CASCADE'))
    user_email = Column(String(255))
    action = Column(String(100))
    corrections = Column(JSON)
    approval_status = Column(String(100))
    feedback_notes = Column(Text)
    feedback_date = Column(DateTime, default=datetime.utcnow)
    processed_by_update_agent = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    entity = relationship('ERDEntity', back_populates='user_feedback')
    document = relationship('Document', back_populates='user_feedback')
    validation = relationship('ValidationResult', back_populates='user_feedback')
    
    def __repr__(self):
        return f"<UserFeedback(id={self.feedback_id}, action={self.action}, user={self.user_email})>"


class AuditTrail(Base):
    """
    Audit Trail table - All agents log their actions here
    Provides complete traceability of all agent operations
    """
    __tablename__ = 'audit_trail'
    
    audit_id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(String(255), ForeignKey('documents.document_id', ondelete='CASCADE'))
    entity_id = Column(Integer, ForeignKey('erd_entities.entity_id', ondelete='SET NULL'), nullable=True)
    agent_name = Column(String(100))
    action = Column(String(255))
    action_details = Column(JSON)
    status = Column(String(100))
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    document = relationship('Document', back_populates='audit_trail')
    entity = relationship('ERDEntity', back_populates='audit_trail')
    
    def __repr__(self):
        return f"<AuditTrail(id={self.audit_id}, agent={self.agent_name}, action={self.action})>"


class MasterRawMaterial(Base):
    """
    Master Raw Materials table - Deduplicated list of unique raw materials
    Each unique ingredient gets ONE record with a globally unique ID
    """
    __tablename__ = 'master_raw_materials'
    
    raw_material_id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    enterprise_erp_id = Column(String(255), nullable=True)
    ingredient_name = Column(String(500), nullable=False)
    cas_number = Column(String(100))
    chemical_formula = Column(String(255))
    supplier_name = Column(String(500))
    material_category = Column(String(100))
    unit_of_measure = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    compositions = relationship('ProductRawMaterialComposition', back_populates='raw_material', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f"<MasterRawMaterial(id={self.raw_material_id}, name={self.ingredient_name}, erp_id={self.enterprise_erp_id})>"


class ProductRawMaterialComposition(Base):
    """
    Product-Raw Material Composition table - Junction table linking products to raw materials
    Stores the relationship, quantity, and function for each ingredient in a product
    """
    __tablename__ = 'product_raw_material_composition'
    
    composition_id = Column(Integer, primary_key=True, autoincrement=True)
    product_entity_id = Column(Integer, ForeignKey('erd_entities.entity_id', ondelete='CASCADE'))
    raw_material_id = Column(String(36), ForeignKey('master_raw_materials.raw_material_id', ondelete='CASCADE'))
    document_id = Column(String(255), ForeignKey('documents.document_id', ondelete='CASCADE'))
    document_rmc_code = Column(String(100))
    quantity = Column(String(100))
    function = Column(String(500))
    extraction_confidence = Column(DECIMAL(5, 2))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    product_entity = relationship('ERDEntity')
    raw_material = relationship('MasterRawMaterial', back_populates='compositions')
    document = relationship('Document')
    
    def __repr__(self):
        return f"<ProductRawMaterialComposition(id={self.composition_id}, product={self.product_entity_id}, material={self.raw_material_id})>"


class DatabaseManager:
    """
    Database Manager - Handles database connections and sessions
    Provides utility methods for all agents to interact with the database
    """
    
    def __init__(self, database_url=None):
        """
        Initialize database connection
        
        Args:
            database_url: PostgreSQL connection string. If None, reads from DATABASE_URL env var
        """
        self.database_url = database_url or os.getenv('DATABASE_URL')
        if not self.database_url:
            raise ValueError("DATABASE_URL not provided and not found in environment variables")
        
        self.engine = create_engine(self.database_url)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
    
    def get_session(self):
        """Get a new database session"""
        return self.SessionLocal()
    
    def create_tables(self):
        """Create all tables (if they don't exist)"""
        Base.metadata.create_all(bind=self.engine)
    
    def drop_tables(self):
        """Drop all tables (USE WITH CAUTION)"""
        Base.metadata.drop_all(bind=self.engine)
    
    def add_document(self, session, document_data):
        """
        Add a new document to the database
        
        Args:
            session: SQLAlchemy session
            document_data: Dictionary with document fields
        
        Returns:
            Document object
        """
        document = Document(**document_data)
        session.add(document)
        session.commit()
        session.refresh(document)
        return document
    
    def update_document_status(self, session, document_id, new_status):
        """
        Update document processing status
        
        Args:
            session: SQLAlchemy session
            document_id: Document ID
            new_status: New status value
        """
        document = session.query(Document).filter(Document.document_id == document_id).first()
        if document:
            document.processing_status = new_status
            document.updated_at = datetime.utcnow()
            session.commit()
            return document
        return None
    
    def get_document(self, session, document_id):
        """Get a document by ID"""
        return session.query(Document).filter(Document.document_id == document_id).first()
    
    def get_documents_by_status(self, session, status):
        """Get all documents with a specific status"""
        return session.query(Document).filter(Document.processing_status == status).all()
    
    def add_audit_log(self, session, audit_data):
        """
        Add an audit trail entry
        
        Args:
            session: SQLAlchemy session
            audit_data: Dictionary with audit fields
        
        Returns:
            AuditTrail object
        """
        audit = AuditTrail(**audit_data)
        session.add(audit)
        session.commit()
        session.refresh(audit)
        return audit
    
    def check_duplicate(self, session, document_id):
        """
        Check if a document already exists in the database
        
        Args:
            session: SQLAlchemy session
            document_id: Document ID to check
        
        Returns:
            True if document exists, False otherwise
        """
        existing = session.query(Document).filter(Document.document_id == document_id).first()
        return existing is not None
