import os
import json
import logging
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class ConfigManager:
    """
    Manages connection configurations from multiple sources:
    - Job property files (JSON)
    - Environment variables
    - Direct user input
    """
    
    def __init__(self, config_file: Optional[str] = None):
        """
        Initialize the configuration manager.
        
        Args:
            config_file: Path to job configuration file (optional)
        """
        self.config_file = config_file or "job_config.json"
        self.config: Dict = {}
        
        if os.path.exists(self.config_file):
            self.load_from_file()
    
    def load_from_file(self) -> bool:
        """
        Load configuration from job property file.
        
        Returns:
            bool: True if successful
        """
        try:
            with open(self.config_file, 'r') as f:
                self.config = json.load(f)
            logger.info(f"✓ Loaded configuration from {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error loading config file: {str(e)}")
            return False
    
    def save_to_file(self) -> bool:
        """
        Save current configuration to job property file.
        
        Returns:
            bool: True if successful
        """
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
            logger.info(f"✓ Saved configuration to {self.config_file}")
            return True
        except Exception as e:
            logger.error(f"Error saving config file: {str(e)}")
            return False
    
    def load_from_env(self, source_type: str) -> Dict:
        """
        Load configuration from environment variables.
        
        Args:
            source_type: Type of source (e.g., 'veeva', 'googledrive', etc.)
            
        Returns:
            Configuration dictionary
        """
        config = {
            "source_type": source_type
        }
        
        if source_type == "veeva":
            config.update({
                "vault_dns": os.getenv('VEEVA_VAULT_DNS', ''),
                "username": os.getenv('VEEVA_USERNAME', ''),
                "password": os.getenv('VEEVA_PASSWORD', ''),
                "api_version": os.getenv('VEEVA_API_VERSION', 'v25.2')
            })
        elif source_type == "googledrive":
            config.update({
                "folder_name": os.getenv('GDRIVE_FOLDER_NAME', 'DigitisationEngineSource'),
                "folder_id": os.getenv('GDRIVE_FOLDER_ID', ''),
                "client_id": os.getenv('GOOGLE_CLIENT_ID', ''),
                "client_secret": os.getenv('GOOGLE_CLIENT_SECRET', '')
            })
        
        logger.info(f"Loaded {source_type} configuration from environment variables")
        return config
    
    def get_source_config(self, source_name: Optional[str] = None) -> Optional[Dict]:
        """
        Get configuration for a specific source.
        
        Args:
            source_name: Name of the source (optional, uses default if not provided)
            
        Returns:
            Source configuration or None
        """
        if not self.config:
            return None
        
        if source_name:
            sources = self.config.get('sources', {})
            return sources.get(source_name)
        else:
            default_source = self.config.get('default_source')
            if default_source:
                sources = self.config.get('sources', {})
                return sources.get(default_source)
        
        return None
    
    def add_source(self, source_name: str, source_config: Dict) -> bool:
        """
        Add a new source configuration.
        
        Args:
            source_name: Name for this source
            source_config: Configuration dictionary
            
        Returns:
            bool: True if successful
        """
        if 'sources' not in self.config:
            self.config['sources'] = {}
        
        self.config['sources'][source_name] = source_config
        
        if 'default_source' not in self.config:
            self.config['default_source'] = source_name
        
        logger.info(f"Added source configuration: {source_name}")
        return True
    
    def set_default_source(self, source_name: str) -> bool:
        """
        Set the default source.
        
        Args:
            source_name: Name of the source to set as default
            
        Returns:
            bool: True if successful
        """
        if 'sources' in self.config and source_name in self.config['sources']:
            self.config['default_source'] = source_name
            logger.info(f"Set default source to: {source_name}")
            return True
        else:
            logger.error(f"Source not found: {source_name}")
            return False
    
    def list_sources(self) -> list:
        """
        List all configured sources.
        
        Returns:
            List of source names
        """
        if 'sources' in self.config:
            return list(self.config['sources'].keys())
        return []
    
    def get_workflow_config(self) -> Dict:
        """
        Get workflow configuration.
        
        Returns:
            Workflow configuration dictionary
        """
        return self.config.get('workflow', {
            'mode': 'auto',
            'document_limit': 10,
            'download_files': True,
            'query': None
        })
    
    def set_workflow_config(self, workflow_config: Dict) -> bool:
        """
        Set workflow configuration.
        
        Args:
            workflow_config: Workflow configuration dictionary
            
        Returns:
            bool: True if successful
        """
        self.config['workflow'] = workflow_config
        logger.info("Updated workflow configuration")
        return True
