"""
Extraction Agent - OCR and Data Parsing for Document Digitisation Pipeline

This agent:
1. Reads unprocessed documents from the database
2. Performs OCR on PDF files to extract text
3. Parses extracted text to identify key data (ingredients, SKU, suppliers, etc.)
4. Stores extracted data in the database
5. Updates document status to "Data Extracted"
6. Logs all actions to the audit trail

Author: Connection Agent Team
Created: October 26, 2025
"""

import os
import re
import logging
import shutil
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from pathlib import Path

import pytesseract
import fitz
from PIL import Image
import io

from src.database_models import DatabaseManager, Document, AuditTrail
from sqlalchemy import and_

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ExtractionAgent:
    """
    Extraction Agent for OCR and intelligent data parsing
    """
    
    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        """
        Initialize the Extraction Agent
        
        Args:
            db_manager: DatabaseManager instance (optional, will create if None)
        """
        self.db_manager = db_manager
        if self.db_manager is None:
            database_url = os.getenv('DATABASE_URL')
            if database_url:
                self.db_manager = DatabaseManager(database_url)
                logger.info("✓ Database manager initialized for extraction agent")
            else:
                raise ValueError("DATABASE_URL environment variable not set")
        
        self.output_dir = Path("downloads")
        self.extracted_count = 0
        self.failed_count = 0
        
    def get_unprocessed_documents(self, limit: int = 10) -> List[Document]:
        """
        Retrieve documents from database with status 'Extracted - Not Processed'
        
        Args:
            limit: Maximum number of documents to process
            
        Returns:
            List of Document objects
        """
        logger.info(f"\n[EXTRACTION AGENT] Querying database for unprocessed documents (limit: {limit})...")
        
        session = self.db_manager.get_session()
        try:
            documents = session.query(Document).filter(
                Document.processing_status == "Extracted - Not Processed"
            ).limit(limit).all()
            
            logger.info(f"✓ Found {len(documents)} unprocessed documents")
            return documents
            
        except Exception as e:
            logger.error(f"Error querying database: {str(e)}")
            return []
        finally:
            session.close()
    
    def perform_ocr(self, pdf_path: str) -> str:
        """
        Extract text from PDF using hybrid approach:
        1. Try PyMuPDF text extraction first (fast, for digital PDFs)
        2. Fall back to Tesseract OCR only for scanned/image pages
        
        Args:
            pdf_path: Path to the PDF file
            
        Returns:
            Extracted text as a string
        """
        logger.info(f"Extracting text from {pdf_path}...")
        
        try:
            doc = fitz.open(pdf_path)
            page_count = len(doc)
            logger.info(f"✓ Opened PDF with {page_count} pages")
            
            extracted_text = []
            ocr_pages = 0
            
            for page_num in range(page_count):
                logger.info(f"Processing page {page_num + 1}/{page_count}...")
                
                page = doc[page_num]
                
                text = page.get_text()
                
                if text and len(text.strip()) > 50:
                    logger.info(f"  → Using text extraction ({len(text)} chars)")
                    extracted_text.append(text)
                else:
                    logger.info(f"  → Page appears to be scanned, using OCR...")
                    ocr_pages += 1
                    
                    pix = page.get_pixmap(dpi=300)
                    img_data = pix.tobytes("png")
                    image = Image.open(io.BytesIO(img_data))
                    
                    text = pytesseract.image_to_string(
                        image,
                        config='--psm 6 --oem 3'
                    )
                    extracted_text.append(text)
            
            doc.close()
            
            full_text = "\n\n=== PAGE BREAK ===\n\n".join(extracted_text)
            logger.info(f"✓ Extraction completed: {len(full_text)} characters ({ocr_pages}/{page_count} pages used OCR)")
            
            return full_text
            
        except Exception as e:
            logger.error(f"Text extraction failed: {str(e)}")
            raise
    
    def parse_formulation_data(self, text: str) -> Dict:
        """
        Parse extracted text to identify key formulation data
        
        This intelligent parser looks for:
        - Product name / SKU
        - Ingredients and raw materials
        - Quantities and concentrations
        - Suppliers and manufacturers
        - Regulatory information
        - Batch numbers and codes
        
        Args:
            text: Extracted text from OCR
            
        Returns:
            Dictionary with parsed data
        """
        logger.info("Parsing formulation data from extracted text...")
        
        parsed_data = {
            "product_name": None,
            "sku": None,
            "ingredients": [],
            "suppliers": [],
            "batch_number": None,
            "regulatory_codes": [],
            "extracted_sections": {},
            "confidence": "medium"
        }
        
        lines = text.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            
            if re.search(r'product\s*name|formulation\s*name|title', line, re.IGNORECASE):
                if i + 1 < len(lines):
                    parsed_data["product_name"] = lines[i + 1].strip()
            
            if re.search(r'\b(SKU|Product\s*Code|Item\s*Code)[\s:]+([A-Z0-9\-]+)', line, re.IGNORECASE):
                match = re.search(r'\b(SKU|Product\s*Code|Item\s*Code)[\s:]+([A-Z0-9\-]+)', line, re.IGNORECASE)
                if match:
                    parsed_data["sku"] = match.group(2)
            
            if re.search(r'ingredient|component|raw\s*material|composition', line, re.IGNORECASE):
                ingredient_section = []
                for j in range(i + 1, min(i + 20, len(lines))):
                    ingredient_line = lines[j].strip()
                    if ingredient_line and not re.search(r'total|sum|section|table', ingredient_line, re.IGNORECASE):
                        ingredient_section.append(ingredient_line)
                    if re.search(r'total|sum|^$', ingredient_line, re.IGNORECASE):
                        break
                parsed_data["ingredients"] = ingredient_section[:10]
            
            if re.search(r'supplier|manufacturer|vendor|source', line, re.IGNORECASE):
                supplier_match = re.search(r'(supplier|manufacturer|vendor)[\s:]+(.+)', line, re.IGNORECASE)
                if supplier_match:
                    parsed_data["suppliers"].append(supplier_match.group(2).strip())
            
            if re.search(r'batch|lot\s*number', line, re.IGNORECASE):
                batch_match = re.search(r'(batch|lot)[\s#:]+([A-Z0-9\-]+)', line, re.IGNORECASE)
                if batch_match:
                    parsed_data["batch_number"] = batch_match.group(2)
            
            if re.search(r'\b(CAS|EINECS|EC)\s*#?[\s:]*\d', line, re.IGNORECASE):
                parsed_data["regulatory_codes"].append(line.strip())
        
        if parsed_data["product_name"] or parsed_data["sku"] or parsed_data["ingredients"]:
            parsed_data["confidence"] = "high"
        elif any([parsed_data["suppliers"], parsed_data["batch_number"]]):
            parsed_data["confidence"] = "medium"
        else:
            parsed_data["confidence"] = "low"
        
        logger.info(f"✓ Parsing complete (confidence: {parsed_data['confidence']})")
        logger.info(f"  - Product: {parsed_data['product_name']}")
        logger.info(f"  - SKU: {parsed_data['sku']}")
        logger.info(f"  - Ingredients found: {len(parsed_data['ingredients'])}")
        logger.info(f"  - Suppliers found: {len(parsed_data['suppliers'])}")
        
        return parsed_data
    
    def extract_document(self, document: Document) -> bool:
        """
        Extract and parse a single document
        
        Args:
            document: Document object from database
            
        Returns:
            True if successful, False otherwise
        """
        logger.info(f"\n[EXTRACTION AGENT] Processing document: {document.document_name}")
        logger.info(f"Document ID: {document.document_id}")
        logger.info(f"PDF path: {document.pdf_path}")
        
        try:
            pdf_full_path = Path(document.pdf_path)
            
            if not pdf_full_path.exists():
                logger.error(f"PDF file not found: {pdf_full_path}")
                self._log_audit(document.document_id, "document_extraction", "error", 
                              f"PDF file not found: {pdf_full_path}")
                return False
            
            extracted_text = self.perform_ocr(str(pdf_full_path))
            
            parsed_data = self.parse_formulation_data(extracted_text)
            
            session = self.db_manager.get_session()
            try:
                db_document = session.query(Document).filter(
                    Document.document_id == document.document_id
                ).first()
                
                if db_document:
                    existing_metadata = db_document.raw_metadata or {}
                    existing_metadata['extracted_text'] = extracted_text
                    existing_metadata['parsed_data'] = parsed_data
                    existing_metadata['extraction_date'] = datetime.now().isoformat()
                    
                    db_document.raw_metadata = existing_metadata
                    db_document.processing_status = "Data Extracted"
                    db_document.processed_at = datetime.now()
                    
                    session.commit()
                    logger.info(f"✓ Updated database: status = 'Data Extracted'")
            finally:
                session.close()
            
            self._log_audit(document.document_id, "document_extraction", "success", 
                          f"Extracted {len(extracted_text)} chars, confidence: {parsed_data['confidence']}")
            
            self.extracted_count += 1
            return True
            
        except Exception as e:
            logger.error(f"Extraction failed: {str(e)}")
            self._log_audit(document.document_id, "document_extraction", "error", str(e))
            self.failed_count += 1
            return False
    
    def _log_audit(self, document_id: str, action: str, status: str, error_message: str = ""):
        """
        Log action to audit trail
        
        Args:
            document_id: Document ID
            action: Action performed
            status: Action status (success, error, skipped)
            error_message: Error message if applicable
        """
        session = self.db_manager.get_session()
        try:
            audit = AuditTrail(
                document_id=document_id,
                agent_name="extraction_agent",
                action=action,
                status=status,
                error_message=error_message if status == "error" else None,
                action_details={"timestamp": datetime.now().isoformat()} if status != "error" else {"error": error_message}
            )
            session.add(audit)
            session.commit()
        except Exception as e:
            logger.error(f"Audit logging failed: {str(e)}")
        finally:
            session.close()
    
    def run_extraction_workflow(self, limit: int = 10) -> Dict:
        """
        Run the complete extraction workflow
        
        Args:
            limit: Maximum number of documents to process
            
        Returns:
            Summary dictionary
        """
        logger.info("\n" + "=" * 60)
        logger.info("EXTRACTION AGENT - DOCUMENT DIGITISATION WORKFLOW")
        logger.info("=" * 60)
        
        documents = self.get_unprocessed_documents(limit)
        
        if not documents:
            logger.info("No unprocessed documents found.")
            return {
                "status": "completed",
                "extracted_count": 0,
                "failed_count": 0,
                "total_documents": 0
            }
        
        logger.info(f"\n[EXTRACTION AGENT] Processing {len(documents)} documents...")
        
        for i, document in enumerate(documents, 1):
            logger.info(f"\nProcessing document {i}/{len(documents)}...")
            self.extract_document(document)
        
        logger.info("\n" + "=" * 60)
        logger.info("EXTRACTION WORKFLOW COMPLETED")
        logger.info("=" * 60)
        logger.info(f"✓ Successfully extracted: {self.extracted_count} documents")
        logger.info(f"✗ Failed: {self.failed_count} documents")
        logger.info("=" * 60)
        
        return {
            "status": "completed",
            "extracted_count": self.extracted_count,
            "failed_count": self.failed_count,
            "total_documents": len(documents)
        }
    
    def disconnect(self):
        """Close database connection"""
        if self.db_manager and hasattr(self.db_manager, 'engine'):
            self.db_manager.engine.dispose()
            logger.info("✓ Database connection closed")
