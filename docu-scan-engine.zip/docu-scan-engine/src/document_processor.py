import json
import os
import logging
from typing import Dict, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """
    Processes documents extracted from multiple sources.
    Handles metadata extraction, keyword management, data organization, and database integration.
    Supports both database and file-based storage for multi-agent pipeline.
    """
    
    def __init__(self, output_dir: str = "downloads", db_manager=None, source_system: str = "unknown"):
        """
        Initialize the document processor.
        
        Args:
            output_dir: Directory to store downloaded documents and metadata
            db_manager: DatabaseManager instance for PostgreSQL integration (optional)
            source_system: Name of source system (googledrive, veeva, etc.)
        """
        self.output_dir = output_dir
        self.metadata_file = os.path.join(output_dir, "documents_metadata.json")
        self.db_manager = db_manager
        self.source_system = source_system
        self.db_session = None
        
        os.makedirs(output_dir, exist_ok=True)
        
        self.documents_data: List[Dict] = []
        self.duplicate_documents: List[Dict] = []  # Track duplicates
        
        # Initialize database session if available
        if self.db_manager:
            try:
                self.db_session = self.db_manager.get_session()
                logger.info("✓ Database session initialized for document processing")
            except Exception as e:
                logger.warning(f"Could not initialize database session: {e}")
                logger.info("Will use file-based storage only")
                self.db_session = None
        
        if os.path.exists(self.metadata_file):
            self._load_metadata()
    
    def _load_metadata(self):
        """Load existing metadata from file."""
        try:
            with open(self.metadata_file, 'r') as f:
                self.documents_data = json.load(f)
            logger.info(f"Loaded {len(self.documents_data)} documents from metadata file")
        except Exception as e:
            logger.error(f"Error loading metadata: {str(e)}")
            self.documents_data = []
    
    def _save_metadata(self):
        """Save metadata to file."""
        try:
            with open(self.metadata_file, 'w') as f:
                json.dump(self.documents_data, f, indent=2)
            logger.info(f"✓ Saved metadata for {len(self.documents_data)} documents")
        except Exception as e:
            logger.error(f"Error saving metadata: {str(e)}")
    
    def process_document(self, doc_id: str, metadata: Dict, keywords: List[str], 
                        pdf_path: Optional[str] = None) -> Dict:
        """
        Process a document and store its information in both database and files.
        Detects duplicates and logs them separately.
        
        Args:
            doc_id: Document ID
            metadata: Document metadata from source (Veeva, Google Drive, etc.)
            keywords: Extracted keywords
            pdf_path: Path to downloaded PDF (if available)
            
        Returns:
            Processed document data dictionary
        """
        # Extract document name from different source types
        document_name = (
            metadata.get("name") or              # Google Drive
            metadata.get("name__v") or           # Veeva Vault
            metadata.get("title") or             # Generic
            "Unknown"
        )
        
        # Extract version from different source types
        document_version = (
            metadata.get("version") or           # Google Drive version
            metadata.get("version__v") or        # Veeva version
            metadata.get("versionNumber") or     # Generic
            ""
        )
        
        # Check for duplicates (database first, then files)
        existing_doc = self._find_existing_document(doc_id)
        
        processed_doc = {
            "document_id": doc_id,
            "company_document_id": "",  # Placeholder for company-specific document identifier
            "document_name": document_name,
            "name": metadata.get("name__v", "Unknown"),  # Keep for backward compatibility
            "type": metadata.get("type__v", "Unknown"),
            "subtype": metadata.get("subtype__v", ""),
            "classification": metadata.get("classification__v", ""),
            "lifecycle": metadata.get("lifecycle__v", ""),
            "status": metadata.get("status__v", ""),
            "version": metadata.get("version__v", ""),
            "document_version": document_version,
            "processing_status": "Extracted - Not Processed",
            "keywords": keywords,
            "pdf_path": pdf_path,
            "processed_at": datetime.now().isoformat(),
            "extracted_at": datetime.now().isoformat(),
            # Metadata placeholders for future processing
            "ocr_completed": "",
            "validation_status": "",
            "audit_notes": "",
            "processed_by": "",
            "reviewed_by": "",
            "review_date": "",
            "raw_metadata": metadata
        }
        
        if existing_doc:
            # Document is a duplicate
            duplicate_entry = processed_doc.copy()
            duplicate_entry["error_type"] = "Duplicate"
            duplicate_entry["error_message"] = f"Document already extracted on {existing_doc.get('extracted_at')}"
            duplicate_entry["original_extraction_date"] = existing_doc.get('extracted_at')
            duplicate_entry["duplicate_extraction_date"] = datetime.now().isoformat()
            
            self.duplicate_documents.append(duplicate_entry)
            logger.warning(f"⚠️  Duplicate document detected: {document_name} (ID: {doc_id})")
        else:
            # New document - add to database and files
            self.documents_data.append(processed_doc)
            logger.info(f"✓ Processed document: {document_name} (ID: {doc_id})")
            
            # Write to database if available
            if self.db_session:
                self._save_to_database(processed_doc)
        
        self._save_metadata()
        
        return processed_doc
    
    def _save_to_database(self, document_data: Dict):
        """
        Save document to PostgreSQL database.
        
        Args:
            document_data: Processed document dictionary
        """
        try:
            # Prepare database record
            db_record = {
                "document_id": document_data["document_id"],
                "company_document_id": document_data.get("company_document_id", ""),
                "document_name": document_data["document_name"],
                "document_version": document_data.get("document_version", ""),
                "processing_status": document_data.get("processing_status", "Extracted - Not Processed"),
                "document_type": document_data.get("type", "Unknown"),
                "document_subtype": document_data.get("subtype", ""),
                "classification": document_data.get("classification", ""),
                "lifecycle": document_data.get("lifecycle", ""),
                "status": document_data.get("status", ""),
                "keywords": ", ".join(document_data.get("keywords", [])),
                "pdf_path": document_data.get("pdf_path", ""),
                "source_system": self.source_system,
                "extracted_at": datetime.now(),
                "processed_at": datetime.now(),
                "metadata": document_data.get("raw_metadata", {})
            }
            
            # Insert into database
            self.db_manager.add_document(self.db_session, db_record)
            
            # Add audit trail entry
            audit_entry = {
                "document_id": document_data["document_id"],
                "agent_name": "connection_agent",
                "action": "document_extracted",
                "action_details": {
                    "source": self.source_system,
                    "document_name": document_data["document_name"],
                    "keywords_count": len(document_data.get("keywords", []))
                },
                "status": "success"
            }
            self.db_manager.add_audit_log(self.db_session, audit_entry)
            
            logger.info(f"✓ Saved document {document_data['document_id']} to database")
            
        except Exception as e:
            logger.error(f"Error saving document to database: {str(e)}")
            # Continue with file-based storage even if database fails
    
    def _find_existing_document(self, doc_id: str) -> Optional[Dict]:
        """
        Check if a document with the given ID already exists (database first, then files).
        
        Args:
            doc_id: Document ID to search for
            
        Returns:
            Existing document dict if found, None otherwise
        """
        # Check database first if available
        if self.db_session and self.db_manager:
            try:
                db_doc = self.db_manager.get_document(self.db_session, doc_id)
                if db_doc:
                    return {
                        "document_id": db_doc.document_id,
                        "extracted_at": db_doc.extracted_at.isoformat() if db_doc.extracted_at else None
                    }
            except Exception as e:
                logger.warning(f"Database check failed, falling back to file check: {e}")
        
        # Fall back to in-memory/file check
        for doc in self.documents_data:
            if doc.get("document_id") == doc_id:
                return doc
        return None
    
    def close(self):
        """Close database session if open"""
        if self.db_session:
            try:
                self.db_session.close()
                logger.info("✓ Database session closed")
            except Exception as e:
                logger.warning(f"Error closing database session: {e}")
    
    def get_pdf_path(self, doc_id: str) -> str:
        """
        Generate standardized PDF path for a document.
        
        Args:
            doc_id: Document ID
            
        Returns:
            Path where PDF should be saved
        """
        return os.path.join(self.output_dir, f"document_{doc_id}.pdf")
    
    def search_by_keyword(self, keyword: str) -> List[Dict]:
        """
        Search documents by keyword.
        
        Args:
            keyword: Keyword to search for
            
        Returns:
            List of matching documents
        """
        matches = []
        keyword_lower = keyword.lower()
        
        for doc in self.documents_data:
            doc_keywords = [k.lower() for k in doc.get("keywords", [])]
            if keyword_lower in doc_keywords:
                matches.append(doc)
        
        return matches
    
    def get_statistics(self) -> Dict:
        """
        Get processing statistics.
        
        Returns:
            Dictionary with statistics
        """
        total_docs = len(self.documents_data)
        docs_with_pdf = sum(1 for doc in self.documents_data if doc.get("pdf_path"))
        
        all_keywords = []
        for doc in self.documents_data:
            all_keywords.extend(doc.get("keywords", []))
        
        unique_keywords = set(all_keywords)
        
        doc_types = {}
        for doc in self.documents_data:
            doc_type = doc.get("type", "Unknown")
            doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
        
        return {
            "total_documents": total_docs,
            "documents_with_pdf": docs_with_pdf,
            "unique_keywords": len(unique_keywords),
            "all_keywords": list(unique_keywords),
            "document_types": doc_types
        }
    
    def generate_report(self) -> str:
        """
        Generate a processing report.
        
        Returns:
            Formatted report string
        """
        stats = self.get_statistics()
        
        report = [
            "\n" + "="*60,
            "DOCUMENT DIGITISATION REPORT",
            "="*60,
            f"\nTotal Documents Processed: {stats['total_documents']}",
            f"Documents with PDF: {stats['documents_with_pdf']}",
            f"Unique Keywords: {stats['unique_keywords']}",
            f"\nDocument Types:",
        ]
        
        for doc_type, count in stats['document_types'].items():
            report.append(f"  - {doc_type}: {count}")
        
        report.append(f"\nTop Keywords:")
        keyword_counts = {}
        for doc in self.documents_data:
            for keyword in doc.get("keywords", []):
                keyword_counts[keyword] = keyword_counts.get(keyword, 0) + 1
        
        sorted_keywords = sorted(keyword_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        for keyword, count in sorted_keywords:
            report.append(f"  - {keyword}: {count} documents")
        
        report.append("\n" + "="*60 + "\n")
        
        return "\n".join(report)
    
    def export_to_csv(self, output_file: str = "documents_export.csv") -> bool:
        """
        Export document data to CSV for audit and monitoring.
        Also exports duplicates to a separate error CSV.
        
        Args:
            output_file: CSV file name
            
        Returns:
            bool: True if export successful
        """
        import csv
        
        output_path = os.path.join(self.output_dir, output_file)
        
        try:
            with open(output_path, 'w', newline='', encoding='utf-8') as csvfile:
                if not self.documents_data:
                    logger.warning("No documents to export")
                    return False
                
                # Column order for audit and monitoring table
                fieldnames = [
                    'document_id',
                    'company_document_id',
                    'document_name',
                    'document_version',
                    'processing_status',
                    'type',
                    'subtype',
                    'classification',
                    'lifecycle',
                    'status',
                    'keywords',
                    'pdf_path',
                    'extracted_at',
                    'processed_at',
                    'ocr_completed',
                    'validation_status',
                    'audit_notes',
                    'processed_by',
                    'reviewed_by',
                    'review_date'
                ]
                
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames, extrasaction='ignore')
                writer.writeheader()
                
                for doc in self.documents_data:
                    row = doc.copy()
                    # Convert keywords list to comma-separated string
                    row['keywords'] = ', '.join(doc.get('keywords', []))
                    # Remove raw_metadata from export
                    if 'raw_metadata' in row:
                        del row['raw_metadata']
                    writer.writerow(row)
            
            logger.info(f"✓ Exported {len(self.documents_data)} documents to {output_path}")
            
            # Export duplicates to error CSV if any found
            if self.duplicate_documents:
                self._export_duplicates_csv()
            
            return True
            
        except Exception as e:
            logger.error(f"Error exporting to CSV: {str(e)}")
            return False
    
    def _export_duplicates_csv(self) -> bool:
        """
        Export duplicate/error documents to a separate CSV file.
        
        Returns:
            bool: True if export successful
        """
        import csv
        
        error_file = os.path.join(self.output_dir, "documents_errors.csv")
        
        try:
            with open(error_file, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = [
                    'error_type',
                    'error_message',
                    'document_id',
                    'document_name',
                    'original_extraction_date',
                    'duplicate_extraction_date',
                    'pdf_path',
                    'keywords'
                ]
                
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames, extrasaction='ignore')
                writer.writeheader()
                
                for dup in self.duplicate_documents:
                    row = dup.copy()
                    # Convert keywords list to comma-separated string
                    row['keywords'] = ', '.join(dup.get('keywords', []))
                    # Remove raw_metadata from export
                    if 'raw_metadata' in row:
                        del row['raw_metadata']
                    writer.writerow(row)
            
            logger.warning(f"⚠️  Exported {len(self.duplicate_documents)} duplicate documents to {error_file}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting duplicates CSV: {str(e)}")
            return False
