import os
import sys
import logging
import getpass
from src.connection_agent import ConnectionAgent
from src.config_manager import ConfigManager
from src.database_models import DatabaseManager

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def interactive_setup():
    """Interactive setup for new source connections."""
    print("\n" + "="*60)
    print("CONNECTION AGENT - INTERACTIVE SOURCE SETUP")
    print("="*60)
    
    print("\nAvailable source types:")
    print("  1. Veeva Vault")
    print("  2. Google Drive")
    print("  3. Add more sources later...")
    
    choice = input("\nSelect source type (1-2): ").strip() or "1"
    
    if choice == "1":
        print("\n--- Veeva Vault Configuration ---")
        vault_dns = input("Vault DNS (e.g., qualitydocs-company.veevavault.com): ").strip()
        username = input("Username: ").strip()
        password = getpass.getpass("Password: ")
        api_version = input("API Version (default: v25.2): ").strip() or "v25.2"
        
        source_name = input("Name for this connection (default: veeva_primary): ").strip() or "veeva_primary"
        
        config_manager = ConfigManager()
        config_manager.add_source(source_name, {
            "source_type": "veeva",
            "vault_dns": vault_dns,
            "username": username,
            "password": password,
            "api_version": api_version
        })
        
        config_manager.set_workflow_config({
            "mode": "auto",
            "document_limit": 10,
            "download_files": True
        })
        
        config_manager.save_to_file()
        
        print(f"\n✓ Configuration saved to job_config.json")
        print(f"✓ Default source set to: {source_name}")
        print(f"\n⚠️  SECURITY NOTE: Your password is stored in job_config.json")
        print(f"   For better security, consider using environment variables via Replit Secrets.")
        print(f"   Set VEEVA_PASSWORD in Secrets and remove 'password' from job_config.json")
        
        return True
    
    elif choice == "2":
        print("\n--- Google Drive Configuration ---")
        print("\nAuthentication Options:")
        print("  1. Replit Connector (limited to files created by this app)")
        print("  2. Custom OAuth (full read access - RECOMMENDED)")
        
        auth_choice = input("\nSelect authentication type (1-2, default: 2): ").strip() or "2"
        
        folder_name = input("\nFolder name (default: DigitisationEngineSource): ").strip() or "DigitisationEngineSource"
        folder_id = input("Folder ID (optional, leave blank to search by name): ").strip()
        
        source_name = input("Name for this connection (default: gdrive_primary): ").strip() or "gdrive_primary"
        
        config_manager = ConfigManager()
        
        source_config = {
            "source_type": "googledrive",
            "folder_name": folder_name
        }
        
        if folder_id:
            source_config["folder_id"] = folder_id
        
        if auth_choice == "2":
            print("\n--- OAuth Credentials ---")
            print("See GOOGLE_DRIVE_SETUP.md for instructions on getting these credentials.")
            print("\nYou can:")
            print("  1. Enter them now")
            print("  2. Add them to Replit Secrets (GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET)")
            print("  3. Edit job_config.json later\n")
            
            use_secrets = input("Use Replit Secrets for credentials? (y/n, default: y): ").strip().lower() != 'n'
            
            if not use_secrets:
                client_id = input("Google Client ID: ").strip()
                client_secret = getpass.getpass("Google Client Secret: ")
                
                if client_id and client_secret:
                    source_config["client_id"] = client_id
                    source_config["client_secret"] = client_secret
                    print("\n⚠️  SECURITY NOTE: OAuth credentials stored in job_config.json")
                    print("   For better security, use Replit Secrets instead.")
                else:
                    print("\n💡 TIP: Add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to Replit Secrets")
            else:
                print("\n💡 Make sure to add these to Replit Secrets:")
                print("   - GOOGLE_CLIENT_ID")
                print("   - GOOGLE_CLIENT_SECRET")
        else:
            print("\n💡 Make sure Google Drive is connected in Replit integrations.")
            print("   Note: Replit connector has limited permissions (drive.file scope)")
        
        config_manager.add_source(source_name, source_config)
        
        config_manager.set_workflow_config({
            "mode": "auto",
            "document_limit": 10,
            "download_files": True
        })
        
        config_manager.save_to_file()
        
        print(f"\n✓ Configuration saved to job_config.json")
        print(f"✓ Default source set to: {source_name}")
        
        if auth_choice == "2":
            print(f"\n📖 Next Steps:")
            print(f"   1. Follow GOOGLE_DRIVE_SETUP.md to get OAuth credentials")
            print(f"   2. Add credentials to Replit Secrets or job_config.json")
            print(f"   3. Run: python main.py")
        
        return True
    
    return False


def run_from_config():
    """Run workflow using job configuration file."""
    # Initialize database manager for multi-agent pipeline
    db_manager = None
    try:
        db_manager = DatabaseManager()
        logger.info("✓ PostgreSQL database connected for multi-agent pipeline")
    except Exception as e:
        logger.warning(f"Database not available, using file-based storage only: {e}")
    
    agent = ConnectionAgent(db_manager=db_manager)
    
    if not os.path.exists("job_config.json"):
        print("\n⚠️  No job_config.json found.")
        setup = input("Would you like to set up a new source? (y/n): ").strip().lower()
        if setup == 'y':
            if interactive_setup():
                agent = ConnectionAgent(db_manager=db_manager)
            else:
                return
        else:
            return
    
    if not agent.connect_from_config():
        print("\n❌ Failed to connect using job configuration.")
        return
    
    workflow_config = agent.config_manager.get_workflow_config()
    
    result = agent.run_workflow(
        query=workflow_config.get('query'),
        limit=workflow_config.get('document_limit', 10),
        download_files=workflow_config.get('download_files', True),
        filters=workflow_config.get('filters')
    )
    
    if result.get('success'):
        print(f"\n✓ Successfully processed {result.get('documents_processed')} documents")
        print(f"✓ Output directory: {result.get('output_directory')}")
        if db_manager:
            print(f"✓ Data saved to PostgreSQL database for agent pipeline")


def run_from_env():
    """Run workflow using environment variables."""
    required_vars = ['VEEVA_VAULT_DNS', 'VEEVA_USERNAME', 'VEEVA_PASSWORD']
    missing_vars = [var for var in required_vars if not os.getenv(var)]
    
    if missing_vars:
        print("\n⚠️  Missing required environment variables:")
        for var in missing_vars:
            print(f"  - {var}")
        return False
    
    # Initialize database manager for multi-agent pipeline
    db_manager = None
    try:
        db_manager = DatabaseManager()
        logger.info("✓ PostgreSQL database connected for multi-agent pipeline")
    except Exception as e:
        logger.warning(f"Database not available, using file-based storage only: {e}")
    
    agent = ConnectionAgent(db_manager=db_manager)
    
    if not agent.connect_from_env('veeva'):
        print("\n❌ Failed to connect using environment variables.")
        return False
    
    query = os.getenv('VEEVA_QUERY')
    limit = int(os.getenv('DOCUMENT_LIMIT', '10'))
    download_files = os.getenv('DOWNLOAD_FILES', 'true').lower() == 'true'
    
    result = agent.run_workflow(query=query, limit=limit, download_files=download_files)
    
    if result.get('success'):
        print(f"\n✓ Successfully processed {result.get('documents_processed')} documents")
        print(f"✓ Output directory: {result.get('output_directory')}")
        if db_manager:
            print(f"✓ Data saved to PostgreSQL database for agent pipeline")
    
    return True


def main():
    """Main entry point for the Connection Agent."""
    
    print("\n" + "="*60)
    print("CONNECTION AGENT - DOCUMENT DIGITISATION ENGINE")
    print("="*60)
    print("\nA flexible document extraction system supporting multiple sources.")
    print("Currently supported: Veeva Vault, Google Drive")
    
    mode = os.getenv('CONNECTION_MODE', 'auto')
    
    if mode == 'interactive':
        interactive_setup()
        run_from_config()
    elif mode == 'config':
        run_from_config()
    elif mode == 'env':
        if not run_from_env():
            print("\n💡 Tip: You can also use job_config.json for configuration.")
            print("   Run with CONNECTION_MODE=interactive to set up.")
    else:
        if os.path.exists("job_config.json"):
            print("\n✓ Found job_config.json, using configuration file...")
            run_from_config()
        elif os.getenv('VEEVA_VAULT_DNS'):
            print("\n✓ Found environment variables, using environment configuration...")
            run_from_env()
        else:
            print("\n⚠️  No configuration found.")
            print("\nConfiguration Options:")
            print("  1. Create job_config.json: Run with CONNECTION_MODE=interactive")
            print("  2. Use environment variables: Set VEEVA_VAULT_DNS, VEEVA_USERNAME, VEEVA_PASSWORD")
            print("\nThis is a demo. The agent will connect and extract documents when configured.")


if __name__ == "__main__":
    main()
