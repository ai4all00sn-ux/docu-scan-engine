#!/usr/bin/env python3
"""
Migration Script - Deduplicate Raw Materials
Migrates existing erd_entities raw materials to master_raw_materials table
"""

import os
import sys
from datetime import datetime
from src.database_models import DatabaseManager, ERDEntity, MasterRawMaterial, ProductRawMaterialComposition

def migrate_raw_materials():
    """
    Migrate and deduplicate raw materials from erd_entities to master_raw_materials
    """
    print("\n" + "=" * 60)
    print("RAW MATERIALS MIGRATION - DEDUPLICATION")
    print("=" * 60)
    
    database_url = os.getenv('DATABASE_URL')
    if not database_url:
        print("ERROR: DATABASE_URL not set")
        sys.exit(1)
    
    db = DatabaseManager(database_url)
    
    print("\n1. Creating new tables...")
    try:
        db.create_tables()
        print("✓ Tables created successfully")
    except Exception as e:
        print(f"✓ Tables already exist or created: {str(e)}")
    
    session = db.get_session()
    try:
        print("\n2. Fetching existing raw material entities...")
        raw_material_entities = session.query(ERDEntity).filter(
            ERDEntity.entity_type == 'raw_material'
        ).all()
        
        print(f"✓ Found {len(raw_material_entities)} raw material records")
        
        print("\n3. Deduplicating by ingredient name...")
        ingredient_map = {}
        
        for entity in raw_material_entities:
            ingredient_name = entity.entity_data.get('ingredient_name')
            
            if ingredient_name and ingredient_name.strip():
                ingredient_name = ingredient_name.strip()
                
                if ingredient_name not in ingredient_map:
                    ingredient_map[ingredient_name] = {
                        'name': ingredient_name,
                        'entities': []
                    }
                
                ingredient_map[ingredient_name]['entities'].append(entity)
        
        print(f"✓ Identified {len(ingredient_map)} unique ingredients")
        
        print("\n4. Creating master raw material records...")
        master_materials = {}
        created_count = 0
        
        for ingredient_name, data in ingredient_map.items():
            existing = session.query(MasterRawMaterial).filter(
                MasterRawMaterial.ingredient_name == ingredient_name
            ).first()
            
            if not existing:
                master_material = MasterRawMaterial(
                    ingredient_name=ingredient_name,
                    enterprise_erp_id=None
                )
                session.add(master_material)
                session.flush()
                master_materials[ingredient_name] = master_material
                created_count += 1
            else:
                master_materials[ingredient_name] = existing
        
        session.commit()
        print(f"✓ Created {created_count} new master raw material records")
        
        print("\n5. Creating product-raw material composition records...")
        composition_count = 0
        
        for entity in raw_material_entities:
            ingredient_name = entity.entity_data.get('ingredient_name')
            
            if ingredient_name and ingredient_name.strip():
                ingredient_name = ingredient_name.strip()
                master_material = master_materials.get(ingredient_name)
                
                if master_material:
                    product_entity = session.query(ERDEntity).filter(
                        ERDEntity.document_id == entity.document_id,
                        ERDEntity.entity_type == 'SKU/PRODUCT'
                    ).first()
                    
                    if product_entity:
                        existing_comp = session.query(ProductRawMaterialComposition).filter(
                            ProductRawMaterialComposition.product_entity_id == product_entity.entity_id,
                            ProductRawMaterialComposition.raw_material_id == master_material.raw_material_id,
                            ProductRawMaterialComposition.document_id == entity.document_id
                        ).first()
                        
                        if not existing_comp:
                            composition = ProductRawMaterialComposition(
                                product_entity_id=product_entity.entity_id,
                                raw_material_id=master_material.raw_material_id,
                                document_id=entity.document_id,
                                document_rmc_code=entity.entity_data.get('rmc_code'),
                                quantity=entity.entity_data.get('quantity'),
                                function=entity.entity_data.get('function'),
                                extraction_confidence=entity.extraction_confidence
                            )
                            session.add(composition)
                            composition_count += 1
        
        session.commit()
        print(f"✓ Created {composition_count} composition records")
        
        print("\n6. Migration Summary:")
        print(f"  - Total raw material entities: {len(raw_material_entities)}")
        print(f"  - Unique ingredients: {len(ingredient_map)}")
        print(f"  - Master records created: {created_count}")
        print(f"  - Composition records created: {composition_count}")
        
        print("\n7. Verifying results...")
        master_count = session.query(MasterRawMaterial).count()
        comp_count = session.query(ProductRawMaterialComposition).count()
        print(f"✓ Master raw materials in database: {master_count}")
        print(f"✓ Compositions in database: {comp_count}")
        
        print("\n" + "=" * 60)
        print("MIGRATION COMPLETED SUCCESSFULLY")
        print("=" * 60)
        
    except Exception as e:
        session.rollback()
        print(f"\n❌ Migration failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        session.close()


if __name__ == "__main__":
    migrate_raw_materials()
