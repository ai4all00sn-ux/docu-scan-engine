import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { useState } from 'react';
import Dashboard from './pages/Dashboard';
import Documents from './pages/Documents';
import DocumentDetail from './pages/DocumentDetail';
import Products from './pages/Products';
import RawMaterials from './pages/RawMaterials';
import './App.css';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchType, setSearchType] = useState('raw_material');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Searching for:', searchQuery, 'Type:', searchType);
    // TODO: Implement search functionality
  };

  return (
    <Router>
      <div className="app">
        <nav className="navbar">
          <div className="nav-container">
            <h1 className="nav-title">🤖 Multi-Agent Document Digitization Pipeline</h1>
            <div className="nav-links">
              <Link to="/" className="nav-link">Dashboard</Link>
              <Link to="/documents" className="nav-link">Documents</Link>
              <Link to="/products" className="nav-link">Products</Link>
              <Link to="/raw-materials" className="nav-link">Raw Materials</Link>
            </div>
            <form className="search-bar" onSubmit={handleSearch}>
              <select 
                className="search-type" 
                value={searchType}
                onChange={(e) => setSearchType(e.target.value)}
              >
                <option value="raw_material">Raw Material</option>
                <option value="product">Product</option>
                <option value="document_id">Document ID</option>
              </select>
              <input
                type="text"
                className="search-input"
                placeholder={`Search ${searchType.replace('_', ' ')}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="search-btn">🔍</button>
            </form>
          </div>
        </nav>
        
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/documents" element={<Documents />} />
            <Route path="/documents/:documentId" element={<DocumentDetail />} />
            <Route path="/products" element={<Products />} />
            <Route path="/raw-materials" element={<RawMaterials />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
