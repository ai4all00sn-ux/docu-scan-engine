import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { pipelineAPI } from '../api';
import type { DocumentDetail as DocumentDetailType } from '../types';
import './DocumentDetail.css';

export default function DocumentDetail() {
  const { documentId } = useParams<{ documentId: string }>();
  const [document, setDocument] = useState<DocumentDetailType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (documentId) {
      loadDocument(documentId);
    }
  }, [documentId]);

  const loadDocument = async (id: string) => {
    try {
      const response = await pipelineAPI.getDocumentDetail(id);
      setDocument(response.data);
    } catch (err) {
      console.error('Failed to load document:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading document details...</div>;
  }

  if (!document) {
    return <div className="error">Document not found</div>;
  }

  return (
    <div className="document-detail">
      <div className="detail-header">
        <Link to="/documents" className="back-btn">← Back to Documents</Link>
        <h2>{document.document_name}</h2>
        <div className="detail-meta">
          <span className="meta-item">
            <strong>Status:</strong> {document.processing_status}
          </span>
          <span className="meta-item">
            <strong>Source:</strong> {document.source_system || 'N/A'}
          </span>
          <span className="meta-item">
            <strong>Entities:</strong> {document.entity_count}
          </span>
        </div>
      </div>

      {document.extracted_text_preview && (
        <div className="text-preview">
          <h3>Extracted Text Preview</h3>
          <pre>{document.extracted_text_preview}</pre>
        </div>
      )}

      <div className="entities-section">
        <h3>Extracted Entities ({document.entities.length})</h3>
        <div className="entities-grid">
          {document.entities.map((entity) => (
            <div key={entity.entity_id} className="entity-card">
              <div className="entity-header">
                <span className="entity-type">{entity.entity_type}</span>
                <span className="entity-pk">{entity.primary_key}</span>
              </div>
              <div className="entity-data">
                {Object.entries(entity.entity_data).map(([key, value]) => (
                  <div key={key} className="data-row">
                    <span className="data-key">{key}:</span>
                    <span className="data-value">{String(value)}</span>
                  </div>
                ))}
              </div>
              {entity.extraction_confidence !== null && (
                <div className="entity-confidence">
                  Confidence: {entity.extraction_confidence.toFixed(1)}%
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
