import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { pipelineAPI } from '../api';
import type { PipelineOverview } from '../types';
import './Dashboard.css';

export default function Dashboard() {
  const [overview, setOverview] = useState<PipelineOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pipelineRunning, setPipelineRunning] = useState(false);
  const [pipelineMessage, setPipelineMessage] = useState<string | null>(null);

  useEffect(() => {
    loadOverview();
    // Auto-refresh every 30 seconds
    const interval = setInterval(loadOverview, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadOverview = async (retryCount = 0) => {
    try {
      const response = await pipelineAPI.getOverview();
      setOverview(response.data);
      setError(null);
      setLoading(false);
    } catch (err: any) {
      const errorMessage = err?.message || 'Failed to load pipeline overview';
      console.error('Dashboard error:', errorMessage, err);
      
      // Retry immediately on first failure (handles cold start timeouts)
      if (retryCount < 3) {
        console.log(`Retrying... (attempt ${retryCount + 1}/3)`);
        setTimeout(() => loadOverview(retryCount + 1), 2000);
      } else {
        setError(`${errorMessage}. Retrying automatically...`);
        setLoading(false);
      }
    }
  };

  const [showLogs, setShowLogs] = useState(false);
  const [pipelineLogs, setPipelineLogs] = useState<any[]>([]);
  const [currentAgent, setCurrentAgent] = useState<string | null>(null);

  const checkPipelineProgress = async () => {
    try {
      const response = await fetch('/api/admin/pipeline-progress');
      const data = await response.json();
      
      setPipelineLogs(data.logs || []);
      setCurrentAgent(data.current_agent);
      
      if (!data.is_running && data.status === 'completed') {
        setPipelineRunning(false);
        setPipelineMessage(null);
        loadOverview();
        setTimeout(() => {
          setShowLogs(false);
        }, 5000);
      } else if (!data.is_running && data.status === 'failed') {
        setPipelineRunning(false);
        setPipelineMessage('❌ Pipeline failed. Check logs for details.');
        setTimeout(() => setPipelineMessage(null), 10000);
      }
    } catch (err) {
      console.error('Failed to check pipeline progress:', err);
    }
  };

  const runPipeline = async () => {
    setPipelineRunning(true);
    setShowLogs(true);
    setPipelineLogs([]);
    setPipelineMessage('Starting pipeline...');
    
    try {
      const response = await fetch('/api/admin/run-pipeline', {
        method: 'POST',
      });
      const data = await response.json();
      
      setPipelineMessage(data.message || 'Pipeline started!');
      
      // Poll for progress every 2 seconds
      const progressInterval = setInterval(async () => {
        await checkPipelineProgress();
      }, 2000);
      
      // Stop polling after 3 minutes
      setTimeout(() => {
        clearInterval(progressInterval);
        if (pipelineRunning) {
          setPipelineRunning(false);
          setPipelineMessage('Pipeline may still be running. Check back later.');
        }
      }, 180000);
      
    } catch (err) {
      setPipelineMessage('Failed to start pipeline. Please try again.');
      console.error(err);
      setPipelineRunning(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading pipeline status...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  if (!overview) {
    return <div className="error">No data available</div>;
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return '#4caf50';
      case 'idle':
        return '#ff9800';
      case 'pending':
        return '#9e9e9e';
      default:
        return '#757575';
    }
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h2>Pipeline Overview</h2>
          <button 
            onClick={runPipeline}
            disabled={pipelineRunning}
            style={{
              padding: '0.75rem 1.5rem',
              fontSize: '1rem',
              fontWeight: '600',
              color: 'white',
              backgroundColor: pipelineRunning ? '#9e9e9e' : '#5b7ce6',
              border: 'none',
              borderRadius: '8px',
              cursor: pipelineRunning ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
            }}
            onMouseEnter={(e) => {
              if (!pipelineRunning) {
                e.currentTarget.style.backgroundColor = '#4a6bd4';
              }
            }}
            onMouseLeave={(e) => {
              if (!pipelineRunning) {
                e.currentTarget.style.backgroundColor = '#5b7ce6';
              }
            }}
          >
            {pipelineRunning ? '⏳ Pipeline Running...' : '▶️ Run Pipeline'}
          </button>
        </div>
        {pipelineMessage && (
          <div style={{
            padding: '1rem',
            marginBottom: '1rem',
            backgroundColor: '#e3f2fd',
            border: '1px solid #2196f3',
            borderRadius: '8px',
            color: '#1976d2',
            fontWeight: '500',
          }}>
            {pipelineMessage}
          </div>
        )}
        
        {showLogs && (
          <div style={{
            marginBottom: '1.5rem',
            backgroundColor: '#1e1e1e',
            border: '1px solid #333',
            borderRadius: '8px',
            padding: '1rem',
            maxHeight: '300px',
            overflowY: 'auto',
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '0.5rem',
              paddingBottom: '0.5rem',
              borderBottom: '1px solid #333',
            }}>
              <div style={{ color: '#fff', fontWeight: '600', fontSize: '0.9rem' }}>
                {currentAgent ? `🔄 ${currentAgent}` : '📋 Pipeline Logs'}
              </div>
              <button
                onClick={() => setShowLogs(false)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: '#888',
                  cursor: 'pointer',
                  fontSize: '1.2rem',
                }}
              >
                ✕
              </button>
            </div>
            <div style={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>
              {pipelineLogs.length === 0 ? (
                <div style={{ color: '#888', padding: '1rem', textAlign: 'center' }}>
                  Waiting for pipeline to start...
                </div>
              ) : (
                pipelineLogs.map((log, index) => (
                  <div key={index} style={{
                    color: log.message.includes('✅') ? '#4caf50' : 
                           log.message.includes('❌') ? '#f44336' :
                           log.message.includes('🎉') ? '#ffeb3b' : '#aaa',
                    padding: '0.25rem 0',
                    borderBottom: index < pipelineLogs.length - 1 ? '1px solid #2a2a2a' : 'none',
                  }}>
                    <span style={{ color: '#666', marginRight: '0.5rem' }}>
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                    {log.message}
                  </div>
                ))
              )}
            </div>
          </div>
        )}
        <div className="stats-grid">
          <Link to="/documents" className="stat-card" style={{ textDecoration: 'none', color: 'inherit', cursor: 'pointer' }}>
            <div className="stat-value">{overview.total_documents}</div>
            <div className="stat-label">Documents Extracted</div>
          </Link>
          <Link to="/raw-materials" className="stat-card" style={{ textDecoration: 'none', color: 'inherit', cursor: 'pointer' }}>
            <div className="stat-value">{overview.total_raw_materials}</div>
            <div className="stat-label">Raw Material Records</div>
          </Link>
        </div>
      </div>

      <div className="pipeline-section">
        <h3>Agent Pipeline</h3>
        <div className="agents-timeline">
          {overview.agents.map((agent, index) => {
            const descriptions: Record<string, string> = {
              'Connection Agent': 'Fetches documents from Google Drive',
              'Extraction Agent': 'Extracts text from PDFs using OCR',
              'Normalization Agent': 'Creates structured ERD entities',
              'Qualification Agent': 'Validates against SAP PIM standards',
              'Validation Agent': 'User approval interface for corrections',
              'Update Agent': 'Processes feedback and updates records'
            };
            
            return (
              <div key={agent.agent_type} className="agent-card">
                <div className="agent-header">
                  <div className="agent-number">{index + 1}</div>
                  <div className="agent-info">
                    <h4>{agent.agent_name}</h4>
                    <span 
                      className="agent-status" 
                      style={{ backgroundColor: getStatusColor(agent.status) }}
                    >
                      {agent.status}
                    </span>
                  </div>
                </div>
                <div className="agent-description">{descriptions[agent.agent_name] || ''}</div>
                {index < overview.agents.length - 1 && <div className="agent-arrow">→</div>}
              </div>
            );
          })}
        </div>
      </div>

      <div className="recent-section">
        <h3>Recent Documents</h3>
        <div className="documents-table">
          <table>
            <thead>
              <tr>
                <th>Document Name</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {overview.recent_documents.map((doc) => (
                <tr key={doc.document_id}>
                  <td className="doc-name">{doc.document_name}</td>
                  <td>
                    <span className="status-badge">{doc.processing_status}</span>
                  </td>
                  <td>{new Date(doc.created_at).toLocaleString()}</td>
                  <td>
                    <Link to={`/documents/${doc.document_id}`} className="view-btn">
                      View Details
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
