import { useEffect, useState } from 'react';
import { pipelineAPI } from '../api';
import type { EntityDetail } from '../types';
import './Products.css';

interface ProductWithCompositions extends EntityDetail {
  compositions?: CompositionDetail[];
}

interface CompositionDetail {
  composition_id: number;
  product_name: string;
  ingredient_name: string;
  document_rmc_code: string | null;
  quantity: string | null;
  function: string | null;
  extraction_confidence: number | null;
}

export default function Products() {
  const [products, setProducts] = useState<ProductWithCompositions[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<ProductWithCompositions | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const docsResponse = await pipelineAPI.getDocuments(100);
      
      // Load all entities (products)
      const allProducts: ProductWithCompositions[] = [];
      for (const doc of docsResponse.data) {
        const detailResponse = await pipelineAPI.getDocumentDetail(doc.document_id);
        const docProducts = detailResponse.data.entities.filter(
          (e: EntityDetail) => e.entity_type === 'SKU/PRODUCT'
        );
        allProducts.push(...docProducts);
      }
      setProducts(allProducts);
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadCompositions = async (product: ProductWithCompositions) => {
    try {
      const response = await fetch(`/api/entities/${product.entity_id}/compositions`);
      const compositions = await response.json();
      setSelectedProduct({ ...product, compositions });
    } catch (err) {
      console.error('Failed to load compositions:', err);
    }
  };

  if (loading) {
    return <div className="loading">Loading products...</div>;
  }

  return (
    <div className="products-page">
      <h2>Products ({products.length})</h2>
      <p className="subtitle">Extracted product entities from all documents</p>

      <div className="products-table">
        <table>
          <thead>
            <tr>
              <th>Product Name</th>
              <th>Product Code</th>
              <th>Document</th>
              <th>Confidence</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => {
              const productName = product.entity_data?.product_name || product.primary_key;
              const productCode = product.primary_key;
              
              return (
                <tr key={product.entity_id}>
                  <td className="product-name">{productName}</td>
                  <td>{productCode}</td>
                  <td className="doc-id">{product.document_id.substring(0, 12)}...</td>
                  <td>{product.extraction_confidence?.toFixed(1) || 'N/A'}%</td>
                  <td>
                    <button 
                      className="view-components-btn"
                      onClick={() => loadCompositions(product)}
                    >
                      View Components
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedProduct && (
        <div className="modal-overlay" onClick={() => setSelectedProduct(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Product Components</h3>
              <button className="close-btn" onClick={() => setSelectedProduct(null)}>✕</button>
            </div>
            
            <div className="product-info">
              <div className="info-row">
                <strong>Product:</strong> {selectedProduct.entity_data?.product_name || selectedProduct.primary_key}
              </div>
              <div className="info-row">
                <strong>Code:</strong> {selectedProduct.primary_key}
              </div>
              <div className="info-row">
                <strong>Document:</strong> {selectedProduct.document_id}
              </div>
            </div>

            {selectedProduct.compositions && selectedProduct.compositions.length > 0 ? (
              <div className="compositions-table">
                <table>
                  <thead>
                    <tr>
                      <th>Ingredient</th>
                      <th>RMC Code</th>
                      <th>Quantity</th>
                      <th>Function</th>
                      <th>Confidence</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedProduct.compositions.map((comp) => (
                      <tr key={comp.composition_id}>
                        <td>{comp.ingredient_name}</td>
                        <td>{comp.document_rmc_code || '-'}</td>
                        <td>{comp.quantity || '-'}</td>
                        <td>{comp.function || '-'}</td>
                        <td>{comp.extraction_confidence?.toFixed(1) || 'N/A'}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="no-compositions">
                Loading components...
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
