import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { pipelineAPI } from '../api';
import type { DocumentSummary } from '../types';
import './Documents.css';

export default function Documents() {
  const [documents, setDocuments] = useState<DocumentSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      const response = await pipelineAPI.getDocuments(100);
      setDocuments(response.data);
    } catch (err) {
      console.error('Failed to load documents:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading documents...</div>;
  }

  return (
    <div className="documents-page">
      <h2>All Documents ({documents.length})</h2>
      <div className="documents-grid">
        {documents.map((doc) => (
          <Link key={doc.document_id} to={`/documents/${doc.document_id}`} className="document-card">
            <h3>{doc.document_name}</h3>
            <div className="document-meta">
              <span className="status">{doc.processing_status}</span>
              <span className="entities">{doc.entity_count} entities</span>
            </div>
            <div className="document-date">
              {new Date(doc.created_at).toLocaleDateString()}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
