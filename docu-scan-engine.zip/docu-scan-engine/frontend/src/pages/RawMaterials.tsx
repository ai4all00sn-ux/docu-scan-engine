import { useEffect, useState } from 'react';
import { pipelineAPI } from '../api';
import type { RawMaterialDetail } from '../types';
import './RawMaterials.css';

export default function RawMaterials() {
  const [materials, setMaterials] = useState<RawMaterialDetail[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMaterials();
  }, []);

  const loadMaterials = async () => {
    try {
      const response = await pipelineAPI.getRawMaterials(100);
      setMaterials(response.data);
    } catch (err) {
      console.error('Failed to load raw materials:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading raw materials...</div>;
  }

  return (
    <div className="raw-materials-page">
      <h2>Master Raw Materials ({materials.length})</h2>
      <p className="subtitle">Deduplicated ingredients from all product formulations</p>
      
      <div className="materials-table">
        <table>
          <thead>
            <tr>
              <th>Ingredient Name</th>
              <th>ERP Code</th>
              <th>CAS Number</th>
              <th>Chemical Formula</th>
              <th>Supplier</th>
              <th>Material Category</th>
              <th>Unit of Measure</th>
              <th>Used In Products</th>
            </tr>
          </thead>
          <tbody>
            {materials.map((material) => (
              <tr key={material.raw_material_id}>
                <td className="ingredient-name">{material.ingredient_name}</td>
                <td>{material.enterprise_erp_id || <span className="pending">Pending</span>}</td>
                <td>{material.cas_number || <span className="pending">-</span>}</td>
                <td>{material.chemical_formula || <span className="pending">-</span>}</td>
                <td>{material.supplier_name || <span className="pending">-</span>}</td>
                <td>{material.material_category || <span className="pending">-</span>}</td>
                <td>{material.unit_of_measure || <span className="pending">-</span>}</td>
                <td className="product-count">{material.used_in_products}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
