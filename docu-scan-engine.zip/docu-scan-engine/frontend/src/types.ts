export interface AgentStatus {
  agent_name: string;
  agent_type: string;
  status: string;
  documents_processed: number;
  entities_created: number;
  success_rate: number;
  last_run: string | null;
}

export interface DocumentSummary {
  document_id: string;
  document_name: string;
  processing_status: string;
  entity_count: number;
  created_at: string;
}

export interface PipelineOverview {
  total_documents: number;
  total_entities: number;
  total_raw_materials: number;
  total_compositions: number;
  documents_by_status: Record<string, number>;
  agents: AgentStatus[];
  recent_documents: DocumentSummary[];
}

export interface EntityDetail {
  entity_id: number;
  document_id: string;
  entity_type: string;
  primary_key: string;
  entity_data: Record<string, any>;
  extraction_confidence: number | null;
  created_at: string;
}

export interface DocumentDetail {
  document_id: string;
  document_name: string;
  company_document_id: string | null;
  processing_status: string;
  source_system: string | null;
  extracted_text_preview: string | null;
  entity_count: number;
  entities: EntityDetail[];
  created_at: string;
}

export interface RawMaterialDetail {
  raw_material_id: string;
  ingredient_name: string;
  enterprise_erp_id: string | null;
  cas_number: string | null;
  chemical_formula: string | null;
  supplier_name: string | null;
  material_category: string | null;
  unit_of_measure: string | null;
  used_in_products: number;
  created_at: string;
}
