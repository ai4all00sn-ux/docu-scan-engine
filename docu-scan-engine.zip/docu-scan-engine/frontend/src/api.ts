import axios from 'axios';
import type { PipelineOverview, DocumentDetail, RawMaterialDetail, DocumentSummary } from './types';

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
});

export const pipelineAPI = {
  getOverview: () => api.get<PipelineOverview>('/pipeline/overview'),
  getDocuments: (limit = 50) => api.get<DocumentSummary[]>(`/documents?limit=${limit}`),
  getDocumentDetail: (documentId: string) => api.get<DocumentDetail>(`/documents/${documentId}`),
  getRawMaterials: (limit = 100) => api.get<RawMaterialDetail[]>(`/raw-materials?limit=${limit}`),
  getRawMaterialDetail: (rawMaterialId: string) => api.get<RawMaterialDetail>(`/raw-materials/${rawMaterialId}`),
};

export default api;
