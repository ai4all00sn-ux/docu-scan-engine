# Multi-Agent Document Digitisation Engine

## Overview
An intelligent, multi-agent document processing system with complete extraction and normalization pipeline. The system processes formulation specifications from Google Drive, extracts text via hybrid OCR, and creates structured ERD entities with deduplicated master raw materials for downstream validation and SAP PIM integration. Currently operational: Connection Agent, Extraction Agent (with session leak fixes), and Normalization Agent (with multi-line table parsing and master materials deduplication). 

**Status**: 10/10 documents successfully processed with 73 ERD entities created. Master raw materials implementation complete: 62 raw material records deduplicated to 16 unique ingredients (73% reduction) with 43 product-ingredient composition records.

**Purpose**: Multi-source document extraction, OCR processing, entity normalization with master data management, and SAP PIM validation workflow automation.

**Phase 1 UI**: Full-stack monitoring dashboard deployed (October 27, 2025) showing end-to-end workflow status with drill-down capabilities into documents, entities, and raw materials. FastAPI backend + React TypeScript frontend on port 5000, auto-refresh every 5 seconds, ready for stakeholder demonstrations.

## User Preferences
- Prefers configurable, flexible architecture
- Wants support for multiple document sources
- Values both file-based and environment-based configuration
- Interested in agentic workflows and automation

## System Architecture

### Connection Agent Pattern
The system employs a pluggable adapter architecture, enabling easy integration of new document sources without altering the core logic. The `ConnectionAgent` acts as an orchestrator, utilizing a `ConfigManager` to load configurations from various sources. It then dispatches tasks to specific adapters (e.g., `VeevaVaultAdapter`, `GoogleDriveAdapter`), which inherit from a `BaseSourceAdapter` interface. A `DocumentProcessor` handles source-agnostic document processing, metadata storage, and organization.

### Core Components
- **ConnectionAgent**: The main orchestrator for document extraction workflows, managing adapter lifecycles and orchestrating the complete extraction process.
- **ConfigManager**: Handles job configuration, loading settings from job property files, environment variables, or direct parameters, and supporting multiple source definitions.
- **BaseSourceAdapter**: An abstract interface defining the contract for all source-specific adapters, ensuring consistent methods for authentication, metadata retrieval, and document download.
- **VeevaVaultAdapter**: Implements the `BaseSourceAdapter` for Veeva Vault, supporting session-based authentication, VQL queries, PDF downloads, and keyword extraction.
- **GoogleDriveAdapter**: Implements the `BaseSourceAdapter` for Google Drive, offering dual authentication (Replit Connector or Custom OAuth), automatic token refresh, and keyword extraction from file metadata.
- **DocumentProcessor**: Responsible for source-agnostic document processing, including metadata storage, keyword indexing, and export functionalities (CSV/JSON).
- **Main Application**: The entry point, featuring auto-detection of configuration sources and an interactive setup wizard.

### UI/UX Decisions
The system supports interactive setup and configuration, allowing users to define extraction workflows and source connections easily. Outputs are structured in a `downloads/` directory, containing individual PDF files, a `documents_metadata.json` for complete metadata, and a `documents_export.csv` for tabular data.

**Monitoring Dashboard (Phase 1)**: Full-stack web UI providing real-time visibility into the 6-agent pipeline:
- **Dashboard Page**: Pipeline overview stats (documents, entities, raw materials, compositions), agent timeline showing status for all 6 agents (Connection, Extraction, Normalization as ACTIVE; Qualification, Validation, Update as PENDING)
- **Documents Page**: List of all processed documents with drill-down to extracted text, entities, and raw material compositions
- **Raw Materials Page**: Master ingredients table showing deduplicated materials with usage tracking
- **Architecture**: FastAPI backend (REST API) + React TypeScript frontend, auto-refresh every 5 seconds
- **Deployment**: Single port 5000 deployment with FastAPI serving built React app as static files

### Technical Implementations
- **Configuration**: Supports configuration via `job_config.json`, environment variables, or direct programmatic parameters, with a defined priority order.
- **Database Integration**: Utilizes PostgreSQL for storing extracted documents and metadata, supporting a multi-agent pipeline with comprehensive schema for documents, entities, validation results, and audit trails. SQLAlchemy ORM is used for database models.
  - **Master Raw Materials**: Implements deduplication logic with UUID-based unique identifiers for ingredients, separate from document-specific RMC codes. The `master_raw_materials` table stores unique ingredients with reserved `enterprise_erp_id` fields for SAP integration.
  - **Product Compositions**: Junction table `product_raw_material_composition` links products to raw materials, storing document-specific RMC codes, quantities, functions, and extraction confidence scores. Enables multi-product ingredient tracking and ERP validation.
  - **Backward Compatibility**: Maintains existing `erd_entities` table for legacy workflows while populating new master materials tables for enhanced data quality.
- **Performance Optimization**: Incorporates a hybrid OCR approach, using PyMuPDF for digital PDFs and Tesseract OCR as a fallback for scanned pages to optimize extraction speed.
- **Security**: Employs secure credential storage, HTTPS-only communication, and avoids logging sensitive session tokens or passwords.

## External Dependencies

### Backend (Python 3.11)
- **requests**: HTTP client library for making API calls.
- **sqlalchemy**: SQL toolkit and Object-Relational Mapper for interacting with databases.
- **psycopg2-binary**: PostgreSQL adapter for SQLAlchemy.
- **google-api-python-client**: Client library for interacting with Google APIs, specifically Google Drive.
- **google-auth libraries**: Libraries for OAuth authentication with Google services.
- **fastapi**: Modern web framework for building REST APIs with automatic OpenAPI documentation.
- **uvicorn**: ASGI server for running FastAPI applications.
- **pydantic**: Data validation and settings management using Python type annotations.
- **sse-starlette**: Server-Sent Events support for real-time updates (Phase 2).

### Frontend
- **React 18**: UI library for building component-based interfaces.
- **TypeScript**: Typed superset of JavaScript for better development experience.
- **Vite**: Fast build tool and development server.
- **React Router**: Client-side routing for multi-page navigation.