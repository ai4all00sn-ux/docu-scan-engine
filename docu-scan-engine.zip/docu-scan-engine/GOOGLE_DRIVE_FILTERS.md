# Google Drive Document Filtering Guide

## Overview
The Connection Agent supports powerful filtering options to select specific documents from your Google Drive folder based on document name, file type, dates, and custom metadata.

---

## Configuration Options

### 1. Filter by Document Name

Filter documents containing specific keywords in their name:

```json
{
  "workflow": {
    "document_limit": 10,
    "filters": {
      "name_contains": "Specification"
    }
  }
}
```

**Examples:**
- `"name_contains": "Specification"` - Files with "Specification" in the name
- `"name_contains": "2025"` - Files with "2025" in the name
- `"name_contains": "Contract"` - Files with "Contract" in the name

---

### 2. Filter by File Type

Filter by specific file types (MIME types):

```json
{
  "workflow": {
    "filters": {
      "file_type": "pdf"
    }
  }
}
```

**Supported File Types:**
- `"pdf"` - PDF documents
- `"doc"` or `"docx"` - Word documents
- `"xls"` or `"xlsx"` - Excel spreadsheets
- `"ppt"` or `"pptx"` - PowerPoint presentations
- `"txt"` - Text files
- `"image"` - Images (JPG, PNG, etc.)

---

### 3. Filter by Date

Filter documents modified after a specific date:

```json
{
  "workflow": {
    "filters": {
      "modified_after": "2025-10-01"
    }
  }
}
```

**Format:** `YYYY-MM-DD`

---

### 4. Custom Google Drive Query

For advanced filtering, use custom Google Drive query syntax:

```json
{
  "workflow": {
    "query": "name contains 'Specification' and mimeType='application/pdf'"
  }
}
```

**Example Queries:**

```
# PDFs with "Specification" in name
name contains 'Specification' and mimeType='application/pdf'

# Documents modified after specific date
modifiedTime > '2025-10-01T00:00:00'

# Documents created by specific user
'user@example.com' in owners

# Multiple conditions
name contains 'Contract' and mimeType='application/pdf' and modifiedTime > '2025-01-01T00:00:00'

# Exclude certain files
name contains 'Report' and not name contains 'Draft'
```

---

## Available Google Drive Metadata

The Connection Agent extracts the following metadata from each document:

### Basic Information
- **name** - Document file name
- **id** - Unique Google Drive file ID
- **mimeType** - File type (application/pdf, etc.)
- **size** - File size in bytes
- **description** - File description (if set)
- **webViewLink** - Link to view in Google Drive

### Date/Time Information
- **createdTime** - When the file was created
- **modifiedTime** - When the file was last modified

### Owner & Permissions
- **owners** - List of file owners
  - displayName
  - emailAddress
- **permissions** - Who has access to the file
  - role (owner, writer, reader)
  - emailAddress
  - displayName

### Keywords Extracted
The system automatically extracts keywords from:
- File name
- File description
- File type (PDF, Document, Spreadsheet, etc.)
- Owner name (prefixed with "Owner:")

---

## Complete Configuration Examples

### Example 1: Filter PDFs with "Specification" in name

```json
{
  "default_source": "gdrive_primary",
  "sources": {
    "gdrive_primary": {
      "source_type": "googledrive",
      "folder_name": "DigitisationEngineSource"
    }
  },
  "workflow": {
    "mode": "auto",
    "document_limit": 20,
    "download_files": true,
    "filters": {
      "name_contains": "Specification",
      "file_type": "pdf"
    }
  }
}
```

### Example 2: Recent documents (last 30 days)

```json
{
  "workflow": {
    "document_limit": 50,
    "filters": {
      "modified_after": "2025-09-24"
    }
  }
}
```

### Example 3: Custom query for contracts

```json
{
  "workflow": {
    "document_limit": 100,
    "query": "name contains 'Contract' and (name contains '2025' or name contains '2024')"
  }
}
```

### Example 4: All PDFs in folder (no filtering)

```json
{
  "workflow": {
    "document_limit": 10,
    "download_files": true,
    "filters": {
      "file_type": "pdf"
    }
  }
}
```

---

## Google Drive Query Syntax Reference

### Operators
- `contains` - Text contains string
- `=` - Exact match
- `!=` - Not equal
- `>`, `<`, `>=`, `<=` - Comparisons (dates, sizes)
- `and` - Logical AND
- `or` - Logical OR
- `not` - Logical NOT
- `in` - Item in collection

### Common Query Patterns

```
# Name patterns
name = 'exact_filename.pdf'
name contains 'keyword'
name contains 'keyword1' and name contains 'keyword2'

# File types
mimeType = 'application/pdf'
mimeType = 'application/vnd.google-apps.document'

# Dates
modifiedTime > '2025-10-01T00:00:00'
createdTime >= '2025-01-01T00:00:00' and createdTime <= '2025-12-31T23:59:59'

# Folder membership
'FOLDER_ID' in parents

# Ownership
'user@example.com' in owners

# Combine conditions
name contains 'Report' and mimeType='application/pdf' and modifiedTime > '2025-10-01T00:00:00'
```

---

## Metadata Output

All extracted metadata is saved to:
- **downloads/documents_metadata.json** - Complete metadata in JSON format
- **downloads/documents_export.csv** - Tabular export for Excel/analysis

The metadata includes:
- All Google Drive metadata (raw_metadata field)
- Extracted keywords
- Document classification
- PDF file paths
- Processing timestamps

---

## Tips & Best Practices

1. **Start Simple** - Use `name_contains` for basic filtering
2. **Use Custom Queries** - For complex filtering needs, use Google Drive query syntax
3. **Check Metadata** - Review `documents_metadata.json` to see all available fields
4. **Test Queries** - Start with small `document_limit` values to test queries
5. **Combine Filters** - Use multiple filter conditions for precise results
6. **Date Format** - Always use ISO format: `YYYY-MM-DDTHH:MM:SS` for queries

---

## Need Help?

- **Google Drive Query Syntax:** https://developers.google.com/drive/api/guides/search-files
- **MIME Types Reference:** https://developers.google.com/drive/api/guides/mime-types
- **Date/Time Format:** ISO 8601 format (YYYY-MM-DDTHH:MM:SS)

