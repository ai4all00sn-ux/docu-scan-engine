# 🔌 Connection Agent - Document Digitisation Engine

A flexible, intelligent document extraction system with pluggable source adapters. Currently supports **Veeva Vault** and **Google Drive** with architecture designed for easy expansion to other document sources.

## 🌟 Key Features

- **Multi-Source Support**: Pluggable architecture for different document sources (Google Drive, Veeva Vault)
- **Document Filtering**: Filter by name, file type, and modification date
- **Duplicate Detection**: Automatic detection of already-extracted documents with error logging
- **Audit-Ready Export**: CSV export with company document ID, version, and status tracking
- **Flexible Configuration**: Use job config files, environment variables, or direct input
- **Secure Authentication**: Environment-based credential management with OAuth support
- **Automated Workflows**: Intelligent batch processing with comprehensive error handling
- **Rich Metadata**: Automatic keyword extraction and document classification
- **Multiple Export Formats**: JSON and CSV export with audit/monitoring columns
- **Quality Control**: Separate error log for duplicates and extraction issues

## 🚀 Quick Start

### Option 1: Using Job Configuration File (Recommended)

1. **Interactive Setup**:
```bash
CONNECTION_MODE=interactive python main.py
```

This will guide you through creating a `job_config.json` file with your connection details.

2. **Run the Workflow**:
```bash
python main.py
```

The agent will automatically use your saved configuration.

### Option 2: Using Environment Variables

Set your environment variables in Replit Secrets:
```
VEEVA_VAULT_DNS=qualitydocs-yourcompany.veevavault.com
VEEVA_USERNAME=your.email@company.com
VEEVA_PASSWORD=your_password
```

Then run:
```bash
python main.py
```

### Option 3: Using Configuration File Directly

Copy and edit the example configuration:
```bash
cp job_config.example.json job_config.json
# Edit job_config.json with your credentials
python main.py
```

## 📋 Configuration

### Job Configuration File (`job_config.json`)

```json
{
  "default_source": "gdrive_primary",
  "sources": {
    "veeva_primary": {
      "source_type": "veeva",
      "vault_dns": "qualitydocs-yourcompany.veevavault.com",
      "username": "your.email@company.com",
      "password": "your_password",
      "api_version": "v25.2"
    },
    "gdrive_primary": {
      "source_type": "googledrive",
      "folder_name": "DigitisationEngineSource"
    }
  },
  "workflow": {
    "mode": "auto",
    "document_limit": 10,
    "download_files": true,
    "query": null
  }
}
```

### Environment Variables

#### General Settings
| Variable | Required | Description | Default |
|----------|----------|-------------|---------|
| `CONNECTION_MODE` | No | Run mode: `auto`, `config`, `env`, `interactive` | `auto` |
| `DOCUMENT_LIMIT` | No | Max documents to process | `10` |
| `DOWNLOAD_FILES` | No | Download PDFs (true/false) | `true` |

#### Veeva Vault Settings
| Variable | Required | Description | Default |
|----------|----------|-------------|---------|
| `VEEVA_VAULT_DNS` | Yes* | Veeva Vault DNS | - |
| `VEEVA_USERNAME` | Yes* | Veeva username | - |
| `VEEVA_PASSWORD` | Yes* | Veeva password | - |
| `VEEVA_API_VERSION` | No | Veeva API version | `v25.2` |
| `VEEVA_QUERY` | No | Custom VQL query | - |

#### Google Drive Settings
| Variable | Required | Description | Default |
|----------|----------|-------------|---------|
| `GDRIVE_FOLDER_NAME` | No | Google Drive folder name | `DigitisationEngineSource` |
| `GDRIVE_FOLDER_ID` | No | Google Drive folder ID | - |

*Required only when using environment-based configuration with that source

## 🔄 Connection Modes

### AUTO (Default)
Automatically detects configuration source:
1. Checks for `job_config.json`
2. Falls back to environment variables
3. Shows setup instructions if neither found

```bash
python main.py
```

### CONFIG
Explicitly use job configuration file:
```bash
CONNECTION_MODE=config python main.py
```

### ENV
Explicitly use environment variables:
```bash
CONNECTION_MODE=env python main.py
```

### INTERACTIVE
Set up a new source configuration interactively:
```bash
CONNECTION_MODE=interactive python main.py
```

## 🏗️ Architecture

### Pluggable Source Adapters

```
┌─────────────────────────────────────────┐
│         Connection Agent                 │
│      (Orchestration Layer)               │
└──────────────┬──────────────────────────┘
               │
               ├──► Base Source Adapter (Abstract)
               │    
               ├──► Veeva Vault Adapter
               │    - Session authentication
               │    - VQL queries
               │    - PDF downloads
               │
               ├──► Google Drive Adapter
               │    - OAuth via Replit connector
               │    - Folder-based extraction
               │    - Auto file type detection
               │
               └──► [Future: SharePoint, Box, S3, etc.]
```

### Core Components

1. **ConnectionAgent** - Main orchestrator
2. **ConfigManager** - Handles multiple configuration sources
3. **BaseSourceAdapter** - Abstract interface for all adapters
4. **VeevaVaultAdapter** - Veeva Vault implementation
5. **DocumentProcessor** - Processes and organizes extracted documents

### Adding New Sources

To add a new document source, create an adapter:

```python
from src.base_source_adapter import BaseSourceAdapter

class MySourceAdapter(BaseSourceAdapter):
    def authenticate(self) -> bool:
        # Implement authentication
        pass
    
    def get_documents_metadata(self, query, limit) -> List[Dict]:
        # Implement document discovery
        pass
    
    # Implement other required methods...
```

Register in `ConnectionAgent.ADAPTER_MAP`:
```python
ADAPTER_MAP = {
    'veeva': VeevaVaultAdapter,
    'my_source': MySourceAdapter,
}
```

## 📁 Project Structure

```
.
├── src/
│   ├── connection_agent.py       # Main orchestrator
│   ├── config_manager.py         # Configuration management
│   ├── base_source_adapter.py    # Abstract adapter interface
│   ├── document_processor.py     # Document processing
│   └── adapters/
│       ├── veeva_adapter.py      # Veeva Vault implementation
│       └── __init__.py
├── main.py                        # Application entry point
├── job_config.json               # Your connection config (create from example)
├── job_config.example.json       # Example configuration
├── downloads/                     # Output directory
│   ├── document_*.pdf            # Downloaded files
│   ├── documents_metadata.json   # Full metadata
│   └── documents_export.csv      # CSV export
└── README.md                      # This file
```

## 📊 Workflow Process

1. **Connect**: Authenticate with document source
2. **Discover**: Find documents using queries
3. **Extract**: Download files and retrieve metadata
4. **Process**: Extract keywords and organize data
5. **Report**: Generate analytics and export data

## 💡 Usage Examples

### Extract Specific Document Types
```bash
# Edit job_config.json:
{
  "workflow": {
    "query": "SELECT id, name__v FROM documents WHERE type__v = 'SOP'"
  }
}

python main.py
```

### Process Large Batches
```bash
# Edit job_config.json:
{
  "workflow": {
    "document_limit": 50,
    "download_files": true
  }
}
```

### Metadata Only (No File Downloads)
```bash
# Edit job_config.json:
{
  "workflow": {
    "download_files": false
  }
}
```

### Multiple Source Connections
```json
{
  "sources": {
    "veeva_prod": {
      "source_type": "veeva",
      "vault_dns": "prod.veevavault.com",
      ...
    },
    "gdrive_docs": {
      "source_type": "googledrive",
      "folder_name": "DigitisationEngineSource"
    },
    "gdrive_archive": {
      "source_type": "googledrive",
      "folder_id": "1ZyjCpwSb9EtkWYnWB6k_PerulHhBxkRA"
    }
  },
  "default_source": "gdrive_docs"
}
```

### Google Drive Setup

1. **Connect Google Drive** in Replit integrations
2. **Configure folder** in `job_config.json`:
```json
{
  "source_type": "googledrive",
  "folder_name": "DigitisationEngineSource"
}
```
3. **Run workflow** - authentication handled automatically via Replit connector

## 📤 Output Files

All extracted documents and metadata are stored in the `downloads/` directory:

### Main Export Files

**`documents_export.csv`** - Audit and monitoring table export
- Ready for database import
- Includes: document_id, company_document_id, document_name, document_version, processing_status
- Audit columns: ocr_completed, validation_status, audit_notes, processed_by, reviewed_by, review_date
- Status defaults to "Extracted - Not Processed"
- Company document ID placeholder for your internal tracking

**`documents_metadata.json`** - Complete metadata
- Full JSON export of all document properties
- Keywords, timestamps, raw metadata from source
- Used for duplicate detection on subsequent runs

**`document_{id}.pdf`** - Individual PDF files
- Named with source system ID

### Error Tracking

**`documents_errors.csv`** - Duplicate and error log
- Only created if duplicates are detected
- Tracks documents that were already extracted
- Columns: error_type, error_message, document_id, document_name, original_extraction_date, duplicate_extraction_date
- Prevents duplicate entries in main export

## 🗄️ Database Integration

The Connection Agent now includes **PostgreSQL database integration** for multi-agent pipeline architecture:

### Database Schema

**`documents`** - Main document repository
- Stores all extracted documents with metadata, keywords, and processing status
- Links to other agents via `document_id` foreign key
- Tracks source system, extraction timestamp, and file paths

**`erd_entities`** - Normalized entity data (for Normalization Agent)
- SKU, raw materials, suppliers, and other extracted entities
- Linked to source documents via `document_id`

**`validation_results`** - Quality checks (for Qualification Agent)
- SAP PIM validation results
- Quality scores and compliance status

**`user_feedback`** - Human-in-the-loop validation (for Validation Agent)
- User approvals, rejections, and corrections
- Heat map data for UI visualization

**`audit_trail`** - Complete activity log
- All agent actions logged with timestamps
- Status: success, error, skipped
- Searchable audit history

### Database Features

✅ **Automatic data persistence** - All documents written to PostgreSQL during extraction  
✅ **Status tracking** - Documents flow through pipeline with status updates  
✅ **Agent interoperability** - Shared schema enables data exchange between agents  
✅ **Backward compatibility** - CSV/JSON export still generated for reference  
✅ **Audit logging** - All agent actions recorded in audit_trail table  

### Pipeline Status Flow

```
Extracted - Not Processed → Data Extracted → Normalized → 
Qualified → Pending Validation → Approved → Published
```

Each agent reads from and writes to the database, updating status as documents progress through the pipeline.

## 🔒 Security

- Credentials stored in environment variables or encrypted config files
- HTTPS-only communication
- Session IDs never logged
- Automatic session cleanup
- Passwords never exposed in output

## 📖 API Reference

### ConnectionAgent

```python
from src.connection_agent import ConnectionAgent

# Initialize
agent = ConnectionAgent()

# Connect from config file
agent.connect_from_config()

# Connect from environment
agent.connect_from_env('veeva')

# Connect with direct parameters
agent.connect_direct('veeva', {
    'vault_dns': 'vault.example.com',
    'username': 'user@example.com',
    'password': 'password'
})

# Run workflow
result = agent.run_workflow(limit=10, download_files=True)
```

### ConfigManager

```python
from src.config_manager import ConfigManager

config = ConfigManager('job_config.json')
config.add_source('my_source', {...})
config.save_to_file()
```

## 🛠️ Development

### Prerequisites
- Python 3.11+
- requests library

### Installation
Dependencies are automatically managed. Just run:
```bash
python main.py
```

## 🚀 Roadmap

**Completed:**
- [x] Google Drive adapter with OAuth
- [x] Database storage (PostgreSQL multi-agent pipeline)

**In Progress:**
- [ ] Extraction Agent (OCR/data parsing)
- [ ] Normalization Agent (ERD entity creation)

**Planned:**
- [ ] SharePoint adapter
- [ ] Box.com adapter
- [ ] S3 bucket adapter
- [ ] Qualification Agent (SAP PIM validation)
- [ ] Validation Agent with UI/heat map
- [ ] Update Agent (feedback processing)
- [ ] Consumability API Agent
- [ ] Web interface
- [ ] Multi-language support

## 📝 License

This is a demonstration project for document source integration.

## 🤝 Resources

- [Veeva Developer Portal](https://developer.veevavault.com/)
- [Veeva API Reference](https://developer.veevavault.com/api/)
