# 📦 Connection Agent - Deployment Guide

## 🎯 Overview

The Connection Agent is ready to deploy as a standalone document digitization engine. This guide will help you deploy it to extract documents from Google Drive and/or Veeva Vault with full metadata, duplicate detection, and audit-ready CSV exports.

---

## ✅ Pre-Deployment Checklist

### 1. Required Configuration

- [ ] Google OAuth credentials (for Google Drive) **OR** Replit Google Drive connector
- [ ] Veeva Vault credentials (if using Veeva)
- [ ] Target folder names configured
- [ ] Document filters set (optional)

### 2. Files to Configure

- [ ] `job_config.json` - Main configuration file
- [ ] Environment variables in Replit Secrets (alternative to job_config.json)

---

## 🚀 Deployment Steps

### Step 1: Choose Your Configuration Method

**Option A: Job Configuration File (Recommended)**
```bash
# Copy the example config
cp job_config.example.json job_config.json

# Edit with your settings
# (Use the Files panel on the right)
```

**Option B: Environment Variables**
Set these in Replit Secrets:
- `GOOGLE_CLIENT_ID`
- `GOOGLE_CLIENT_SECRET`
- Or other source-specific variables

### Step 2: Configure Google Drive (if using)

**For Custom OAuth (Full Access):**
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create OAuth 2.0 credentials
3. Add to Replit Secrets:
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
4. Set your folder name in `job_config.json`

**For Replit Connector (Limited Access):**
1. Use the Replit Google Drive integration
2. No manual OAuth setup needed
3. Limited to files created by the app

See `GOOGLE_DRIVE_SETUP.md` for detailed instructions.

### Step 3: Configure Document Filters

Edit `job_config.json` line 15:

```json
"filters": {
  "name_contains": "Formulation_Spec",  // Filter by filename
  "file_type": null,                     // Filter by type (pdf, doc, etc.)
  "modified_after": null                 // Filter by date (YYYY-MM-DD)
}
```

**Examples:**
- All documents: `"name_contains": null`
- Specifications only: `"name_contains": "Specification"`
- PDFs only: `"file_type": "pdf"`
- Recent docs: `"modified_after": "2025-10-01"`

### Step 4: Test the Extraction

Click the green **Run** button or:
```bash
python main.py
```

**Expected Output:**
- Console shows extraction progress
- `downloads/` folder contains:
  - `document_*.pdf` - Extracted PDFs
  - `documents_export.csv` - Main audit export
  - `documents_errors.csv` - Duplicate detection log (if duplicates found)

### Step 5: Verify Output Files

**Check `documents_export.csv`:**
- Should have all extracted documents
- Status = "Extracted - Not Processed"
- Company document ID placeholder is empty (ready for your IDs)

**Check `documents_errors.csv` (if exists):**
- Lists any duplicate documents detected
- Shows original vs. duplicate extraction dates

---

## 📊 Output Files Explained

### documents_export.csv
**Purpose:** Main audit and monitoring table
**Columns:**
- `document_id` - System ID (Google Drive ID)
- `company_document_id` - Your company's internal ID (placeholder)
- `document_name` - Actual filename
- `document_version` - Version placeholder
- `processing_status` - "Extracted - Not Processed"
- `extracted_at` - Extraction timestamp
- Plus audit columns: `ocr_completed`, `validation_status`, `audit_notes`, `processed_by`, `reviewed_by`, `review_date`

### documents_errors.csv
**Purpose:** Duplicate detection and error tracking
**Columns:**
- `error_type` - "Duplicate"
- `error_message` - Description
- `document_id` - ID of duplicate document
- `document_name` - Filename
- `original_extraction_date` - When first extracted
- `duplicate_extraction_date` - When duplicate was detected

### documents_metadata.json
**Purpose:** Complete metadata for all documents
**Contents:** Full JSON with all document properties, keywords, and raw metadata

---

## 🔄 Running Scheduled Extractions

### For Regular Extractions:

1. **Daily Extraction:**
   - Clear the `downloads/` folder before each run
   - Or keep existing files to enable duplicate detection

2. **Incremental Extraction:**
   - Use date filters to get only new documents:
   ```json
   "modified_after": "2025-10-26"
   ```

3. **Filtered Extraction:**
   - Use name filters to extract specific document types
   - Change filter in `job_config.json` and re-run

---

## 🛠️ Troubleshooting

### Issue: "No configuration found"
**Solution:** Create `job_config.json` or set environment variables

### Issue: "Folder not found"
**Solution:** 
- Check folder name spelling in `job_config.json`
- Verify you have access to the folder in Google Drive
- For Replit connector, folder must be created by the app

### Issue: "Authentication failed"
**Solution:**
- For Google Drive: Re-run OAuth flow (delete `token.json` and run again)
- For Veeva: Check username/password in configuration

### Issue: Duplicate detection not working
**Solution:** Don't delete `documents_metadata.json` between runs - it tracks previously extracted documents

### Issue: Filter not working
**Solution:** Check for JSON syntax errors in `job_config.json` (commas, quotes)

---

## 🔐 Security Best Practices

1. **Never commit credentials:**
   - `job_config.json` is in `.gitignore`
   - Use Replit Secrets for sensitive data

2. **OAuth tokens:**
   - `token.json` is gitignored
   - Automatically refreshed by the system

3. **Downloaded files:**
   - `downloads/` folder is gitignored
   - Contains potentially sensitive documents

---

## 📈 Integration with Your Workflow

### Step 1: Import CSV to Database
```python
import pandas as pd

# Load the export
df = pd.read_csv('downloads/documents_export.csv')

# Add your company document IDs
df['company_document_id'] = df.apply(assign_company_id, axis=1)

# Import to your database
df.to_sql('audit_table', con=db_connection, if_exists='append')
```

### Step 2: Process Documents
Update the CSV as documents move through your workflow:
- Set `ocr_completed` = "Yes" after OCR
- Set `validation_status` = "Passed" after validation
- Fill in `processed_by`, `reviewed_by`, etc.

### Step 3: Monitor Errors
```python
# Check for duplicates
errors = pd.read_csv('downloads/documents_errors.csv')
if len(errors) > 0:
    print(f"Warning: {len(errors)} duplicate documents detected!")
```

---

## 🎉 You're Ready!

The Connection Agent is now deployed and ready to extract documents with:

✅ Duplicate detection and error logging  
✅ Full metadata extraction  
✅ Audit-ready CSV exports  
✅ Company document ID placeholders  
✅ Processing status tracking  
✅ Configurable filtering  

**Next Steps:**
1. Run your first extraction
2. Verify the output files
3. Integrate with your audit/monitoring system
4. Schedule regular extractions as needed

---

**Need Help?**
- See `README.md` for full documentation
- See `GOOGLE_DRIVE_FILTERS.md` for advanced filtering
- See `GOOGLE_DRIVE_SETUP.md` for OAuth setup
