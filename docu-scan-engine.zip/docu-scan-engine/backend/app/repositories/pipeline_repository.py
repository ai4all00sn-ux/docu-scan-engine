from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from typing import List, Dict, Optional
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '../../../src'))
from database_models import Document, ERDEntity, MasterRawMaterial, ProductRawMaterialComposition

class PipelineRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def get_document_count(self) -> int:
        return self.db.query(func.count(Document.document_id)).scalar() or 0
    
    def get_entity_count(self) -> int:
        return self.db.query(func.count(ERDEntity.entity_id)).scalar() or 0
    
    def get_raw_material_count(self) -> int:
        return self.db.query(func.count(MasterRawMaterial.raw_material_id)).scalar() or 0
    
    def get_composition_count(self) -> int:
        return self.db.query(func.count(ProductRawMaterialComposition.composition_id)).scalar() or 0
    
    def get_documents_by_status(self) -> Dict[str, int]:
        results = self.db.query(
            Document.processing_status,
            func.count(Document.document_id).label('count')
        ).group_by(Document.processing_status).all()
        
        return {status: count for status, count in results}
    
    def get_recent_documents(self, limit: int = 10) -> List[Document]:
        return self.db.query(Document).order_by(desc(Document.created_at)).limit(limit).all()
    
    def get_document_by_id(self, document_id: str) -> Optional[Document]:
        return self.db.query(Document).filter(Document.document_id == document_id).first()
    
    def get_entities_by_document(self, document_id: str) -> List[ERDEntity]:
        return self.db.query(ERDEntity).filter(ERDEntity.document_id == document_id).all()
    
    def get_entity_count_by_document(self, document_id: str) -> int:
        return self.db.query(func.count(ERDEntity.entity_id)).filter(
            ERDEntity.document_id == document_id
        ).scalar() or 0
    
    def get_all_raw_materials(self, limit: int = 100) -> List[MasterRawMaterial]:
        return self.db.query(MasterRawMaterial).order_by(
            MasterRawMaterial.ingredient_name
        ).limit(limit).all()
    
    def get_raw_material_by_id(self, raw_material_id: str) -> Optional[MasterRawMaterial]:
        return self.db.query(MasterRawMaterial).filter(
            MasterRawMaterial.raw_material_id == raw_material_id
        ).first()
    
    def get_compositions_by_raw_material(self, raw_material_id: str) -> List[ProductRawMaterialComposition]:
        return self.db.query(ProductRawMaterialComposition).filter(
            ProductRawMaterialComposition.raw_material_id == raw_material_id
        ).all()
    
    def get_compositions_by_product(self, product_entity_id: int) -> List[ProductRawMaterialComposition]:
        return self.db.query(ProductRawMaterialComposition).filter(
            ProductRawMaterialComposition.product_entity_id == product_entity_id
        ).all()
    
    def get_agent_statistics(self) -> Dict[str, Dict[str, any]]:
        connection_docs = self.db.query(func.count(Document.document_id)).filter(
            Document.source_system.isnot(None)
        ).scalar() or 0
        
        extraction_docs = self.db.query(func.count(Document.document_id)).filter(
            Document.raw_metadata.isnot(None)
        ).scalar() or 0
        
        normalization_entities = self.get_entity_count()
        
        return {
            'connection': {
                'documents_processed': connection_docs,
                'status': 'active' if connection_docs > 0 else 'idle'
            },
            'extraction': {
                'documents_processed': extraction_docs,
                'status': 'active' if extraction_docs > 0 else 'idle'
            },
            'normalization': {
                'entities_created': normalization_entities,
                'status': 'active' if normalization_entities > 0 else 'idle'
            }
        }
