from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime

class AgentStatus(BaseModel):
    agent_name: str
    agent_type: str
    status: str
    documents_processed: int
    entities_created: int
    success_rate: float
    last_run: Optional[datetime] = None
    
    class Config:
        from_attributes = True

class DocumentSummary(BaseModel):
    document_id: str
    document_name: str
    processing_status: str
    entity_count: int
    created_at: datetime
    
    class Config:
        from_attributes = True

class PipelineOverview(BaseModel):
    total_documents: int
    total_entities: int
    total_raw_materials: int
    total_compositions: int
    documents_by_status: Dict[str, int]
    agents: List[AgentStatus]
    recent_documents: List[DocumentSummary]

class EntityDetail(BaseModel):
    entity_id: int
    document_id: str
    entity_type: str
    primary_key: str
    entity_data: Dict[str, Any]
    extraction_confidence: Optional[float]
    created_at: datetime
    
    class Config:
        from_attributes = True

class RawMaterialDetail(BaseModel):
    raw_material_id: str
    ingredient_name: str
    enterprise_erp_id: Optional[str]
    cas_number: Optional[str]
    chemical_formula: Optional[str]
    supplier_name: Optional[str]
    material_category: Optional[str]
    unit_of_measure: Optional[str]
    used_in_products: int
    created_at: datetime
    
    class Config:
        from_attributes = True

class CompositionDetail(BaseModel):
    composition_id: int
    product_name: str
    ingredient_name: str
    document_rmc_code: Optional[str]
    quantity: Optional[str]
    function: Optional[str]
    extraction_confidence: Optional[float]
    
    class Config:
        from_attributes = True

class DocumentDetail(BaseModel):
    document_id: str
    document_name: str
    company_document_id: Optional[str]
    processing_status: str
    source_system: Optional[str]
    extracted_text_preview: Optional[str]
    entity_count: int
    entities: List[EntityDetail]
    created_at: datetime
    
    class Config:
        from_attributes = True
