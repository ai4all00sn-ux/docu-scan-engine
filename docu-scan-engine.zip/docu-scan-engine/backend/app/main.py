from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, Response
from pathlib import Path
from .api import pipeline, admin

app = FastAPI(
    title="Multi-Agent Document Digitization Pipeline",
    description="API for monitoring and managing document digitization workflow",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(pipeline.router)
app.include_router(admin.router)

frontend_dist = Path(__file__).parent.parent.parent / "frontend" / "dist"

if frontend_dist.exists():
    app.mount("/assets", StaticFiles(directory=str(frontend_dist / "assets")), name="assets")
    
    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        if full_path.startswith("api/"):
            return {"error": "API endpoint not found"}
        
        file_path = frontend_dist / full_path
        if file_path.exists() and file_path.is_file():
            response = FileResponse(file_path)
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
            return response
        
        response = FileResponse(frontend_dist / "index.html")
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response
else:
    @app.get("/")
    def root():
        return {
            "message": "Multi-Agent Document Digitization Pipeline API",
            "version": "1.0.0",
            "status": "operational",
            "note": "Frontend not built. Run 'cd frontend && npm run build' to build the UI."
        }

@app.get("/health")
def health_check():
    return {"status": "healthy"}
