from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '../../../src'))
from database_models import ERDEntity

from ..config.database import get_db
from ..repositories.pipeline_repository import PipelineRepository
from ..schemas.pipeline import (
    PipelineOverview, AgentStatus, DocumentSummary, 
    DocumentDetail, EntityDetail, RawMaterialDetail, CompositionDetail
)

router = APIRouter(prefix="/api", tags=["pipeline"])

@router.get("/pipeline/overview", response_model=PipelineOverview)
def get_pipeline_overview(db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    
    total_documents = repo.get_document_count()
    total_entities = repo.get_entity_count()
    total_raw_materials = repo.get_raw_material_count()
    total_compositions = repo.get_composition_count()
    documents_by_status = repo.get_documents_by_status()
    
    agent_stats = repo.get_agent_statistics()
    
    agents = [
        AgentStatus(
            agent_name="Connection Agent",
            agent_type="connection",
            status=agent_stats['connection']['status'],
            documents_processed=agent_stats['connection']['documents_processed'],
            entities_created=0,
            success_rate=100.0 if agent_stats['connection']['documents_processed'] > 0 else 0.0,
            last_run=None
        ),
        AgentStatus(
            agent_name="Extraction Agent",
            agent_type="extraction",
            status=agent_stats['extraction']['status'],
            documents_processed=agent_stats['extraction']['documents_processed'],
            entities_created=0,
            success_rate=100.0 if agent_stats['extraction']['documents_processed'] > 0 else 0.0,
            last_run=None
        ),
        AgentStatus(
            agent_name="Normalization Agent",
            agent_type="normalization",
            status=agent_stats['normalization']['status'],
            documents_processed=total_documents,
            entities_created=agent_stats['normalization']['entities_created'],
            success_rate=100.0 if agent_stats['normalization']['entities_created'] > 0 else 0.0,
            last_run=None
        ),
        AgentStatus(
            agent_name="Qualification Agent",
            agent_type="qualification",
            status="pending",
            documents_processed=0,
            entities_created=0,
            success_rate=0.0,
            last_run=None
        ),
        AgentStatus(
            agent_name="Validation Agent",
            agent_type="validation",
            status="pending",
            documents_processed=0,
            entities_created=0,
            success_rate=0.0,
            last_run=None
        ),
        AgentStatus(
            agent_name="Update Agent",
            agent_type="update",
            status="pending",
            documents_processed=0,
            entities_created=0,
            success_rate=0.0,
            last_run=None
        )
    ]
    
    recent_docs = repo.get_recent_documents(limit=5)
    recent_documents = [
        DocumentSummary(
            document_id=doc.document_id,
            document_name=doc.document_name,
            processing_status=doc.processing_status,
            entity_count=repo.get_entity_count_by_document(doc.document_id),
            created_at=doc.created_at
        )
        for doc in recent_docs
    ]
    
    return PipelineOverview(
        total_documents=total_documents,
        total_entities=total_entities,
        total_raw_materials=total_raw_materials,
        total_compositions=total_compositions,
        documents_by_status=documents_by_status,
        agents=agents,
        recent_documents=recent_documents
    )

@router.get("/documents", response_model=List[DocumentSummary])
def get_all_documents(limit: int = 50, db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    docs = repo.get_recent_documents(limit=limit)
    
    return [
        DocumentSummary(
            document_id=doc.document_id,
            document_name=doc.document_name,
            processing_status=doc.processing_status,
            entity_count=repo.get_entity_count_by_document(doc.document_id),
            created_at=doc.created_at
        )
        for doc in docs
    ]

@router.get("/documents/{document_id}", response_model=DocumentDetail)
def get_document_detail(document_id: str, db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    doc = repo.get_document_by_id(document_id)
    
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    
    entities = repo.get_entities_by_document(document_id)
    
    extracted_text_preview = None
    if doc.raw_metadata and 'extracted_text' in doc.raw_metadata:
        extracted_text = doc.raw_metadata['extracted_text']
        extracted_text_preview = extracted_text[:500] + "..." if len(extracted_text) > 500 else extracted_text
    
    entity_details = [
        EntityDetail(
            entity_id=entity.entity_id,
            document_id=entity.document_id,
            entity_type=entity.entity_type,
            primary_key=entity.primary_key,
            entity_data=entity.entity_data or {},
            extraction_confidence=entity.extraction_confidence,
            created_at=entity.created_at
        )
        for entity in entities
    ]
    
    return DocumentDetail(
        document_id=doc.document_id,
        document_name=doc.document_name,
        company_document_id=doc.company_document_id,
        processing_status=doc.processing_status,
        source_system=doc.source_system,
        extracted_text_preview=extracted_text_preview,
        entity_count=len(entities),
        entities=entity_details,
        created_at=doc.created_at
    )

@router.get("/raw-materials", response_model=List[RawMaterialDetail])
def get_all_raw_materials(limit: int = 100, db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    raw_materials = repo.get_all_raw_materials(limit=limit)
    
    return [
        RawMaterialDetail(
            raw_material_id=rm.raw_material_id,
            ingredient_name=rm.ingredient_name,
            enterprise_erp_id=rm.enterprise_erp_id,
            cas_number=rm.cas_number,
            chemical_formula=rm.chemical_formula,
            supplier_name=rm.supplier_name,
            material_category=rm.material_category,
            unit_of_measure=rm.unit_of_measure,
            used_in_products=len(repo.get_compositions_by_raw_material(rm.raw_material_id)),
            created_at=rm.created_at
        )
        for rm in raw_materials
    ]

@router.get("/raw-materials/{raw_material_id}", response_model=RawMaterialDetail)
def get_raw_material_detail(raw_material_id: str, db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    rm = repo.get_raw_material_by_id(raw_material_id)
    
    if not rm:
        raise HTTPException(status_code=404, detail="Raw material not found")
    
    compositions = repo.get_compositions_by_raw_material(raw_material_id)
    
    return RawMaterialDetail(
        raw_material_id=rm.raw_material_id,
        ingredient_name=rm.ingredient_name,
        enterprise_erp_id=rm.enterprise_erp_id,
        cas_number=rm.cas_number,
        chemical_formula=rm.chemical_formula,
        supplier_name=rm.supplier_name,
        material_category=rm.material_category,
        unit_of_measure=rm.unit_of_measure,
        used_in_products=len(compositions),
        created_at=rm.created_at
    )

@router.get("/entities/{entity_id}/compositions", response_model=List[CompositionDetail])
def get_entity_compositions(entity_id: int, db: Session = Depends(get_db)):
    repo = PipelineRepository(db)
    compositions = repo.get_compositions_by_product(entity_id)
    
    result = []
    for comp in compositions:
        entity = db.query(ERDEntity).filter(
            ERDEntity.entity_id == comp.product_entity_id
        ).first()
        rm = repo.get_raw_material_by_id(comp.raw_material_id)
        
        if entity and rm:
            product_name = entity.entity_data.get('product_name', entity.primary_key) if entity.entity_data else entity.primary_key
            
            result.append(CompositionDetail(
                composition_id=comp.composition_id,
                product_name=product_name,
                ingredient_name=rm.ingredient_name,
                document_rmc_code=comp.document_rmc_code,
                quantity=comp.quantity,
                function=comp.function,
                extraction_confidence=comp.extraction_confidence
            ))
    
    return result
