from fastapi import APIRouter, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
import sys
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List

from ..config.database import get_db
from ..repositories.pipeline_repository import PipelineRepository

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))
from src.database_models import DatabaseManager
from src.connection_agent import ConnectionAgent
from src.extraction_agent import ExtractionAgent
from src.normalization_agent import NormalizationAgent

router = APIRouter(prefix="/api/admin", tags=["admin"])

pipeline_progress = {
    "is_running": False,
    "current_agent": None,
    "logs": [],
    "started_at": None,
    "completed_at": None,
    "status": "idle"
}

def add_log(message: str):
    """Add a timestamped log message"""
    pipeline_progress["logs"].append({
        "timestamp": datetime.now().isoformat(),
        "message": message
    })
    if len(pipeline_progress["logs"]) > 100:
        pipeline_progress["logs"] = pipeline_progress["logs"][-100:]

@router.post("/run-pipeline")
async def run_pipeline(background_tasks: BackgroundTasks):
    """
    Run the complete agent pipeline to populate production database.
    """
    
    def run_agents():
        """Background task to run all agents sequentially"""
        global pipeline_progress
        
        try:
            pipeline_progress["is_running"] = True
            pipeline_progress["started_at"] = datetime.now().isoformat()
            pipeline_progress["status"] = "running"
            pipeline_progress["logs"] = []
            
            # Change to project root directory
            project_root = Path(__file__).parent.parent.parent.parent
            original_dir = os.getcwd()
            os.chdir(str(project_root))
            add_log(f"✓ Working directory: {os.getcwd()}")
            
            db_manager = DatabaseManager()
            add_log("✓ Database connected")
            
            # Run Connection Agent
            pipeline_progress["current_agent"] = "Connection Agent"
            add_log("🔗 Starting Connection Agent...")
            add_log("📥 Fetching documents from Google Drive...")
            
            connection_agent = ConnectionAgent(db_manager=db_manager)
            if not connection_agent.connect_from_config():
                add_log("❌ Connection Agent failed to connect")
                os.chdir(original_dir)
                raise Exception("Connection Agent failed")
            
            workflow_config = connection_agent.config_manager.get_workflow_config()
            result = connection_agent.run_workflow(
                query=workflow_config.get('query'),
                limit=workflow_config.get('document_limit', 10),
                download_files=workflow_config.get('download_files', True),
                filters=workflow_config.get('filters')
            )
            
            if result.get('success'):
                doc_count = result.get('documents_processed', 0)
                add_log(f"✅ Connection Agent completed: {doc_count} documents fetched")
            else:
                add_log("❌ Connection Agent failed")
                raise Exception("Connection Agent failed")
            
            # Run Extraction Agent
            pipeline_progress["current_agent"] = "Extraction Agent"
            add_log("📄 Starting Extraction Agent...")
            add_log("🔍 Extracting text from PDFs using OCR...")
            
            extraction_agent = ExtractionAgent(db_manager=db_manager)
            extraction_result = extraction_agent.run_extraction_workflow(limit=20)
            
            extracted_count = extraction_result.get('extracted_count', 0)
            add_log(f"✅ Extraction Agent completed: {extracted_count} documents processed")
            
            # Run Normalization Agent
            pipeline_progress["current_agent"] = "Normalization Agent"
            add_log("📊 Starting Normalization Agent...")
            add_log("🧬 Creating ERD entities and master materials...")
            
            normalization_agent = NormalizationAgent(db_manager=db_manager)
            normalization_result = normalization_agent.run_normalization_workflow(limit=20)
            
            entity_count = normalization_result.get('normalized_count', 0)
            add_log(f"✅ Normalization Agent completed: {entity_count} entities created")
            
            pipeline_progress["status"] = "completed"
            pipeline_progress["completed_at"] = datetime.now().isoformat()
            add_log("🎉 Pipeline completed successfully!")
            
        except Exception as e:
            pipeline_progress["status"] = "failed"
            pipeline_progress["completed_at"] = datetime.now().isoformat()
            add_log(f"❌ Pipeline failed: {str(e)[:200]}")
            import traceback
            add_log(f"Stack trace: {traceback.format_exc()[:500]}")
        finally:
            # Restore original directory
            try:
                os.chdir(original_dir)
            except:
                pass
            pipeline_progress["is_running"] = False
            pipeline_progress["current_agent"] = None
    
    background_tasks.add_task(run_agents)
    
    return JSONResponse(
        content={
            "status": "started",
            "message": "Pipeline started in background. This will take 1-2 minutes."
        }
    )


@router.get("/pipeline-status")
async def pipeline_status(db: Session = Depends(get_db)):
    """Quick check to see if pipeline has run"""
    repo = PipelineRepository(db)
    
    total_documents = repo.get_document_count()
    total_entities = repo.get_entity_count()
    
    has_data = total_documents > 0 or total_entities > 0
    
    return {
        "has_data": has_data,
        "total_documents": total_documents,
        "total_entities": total_entities,
        "message": "Production database populated" if has_data else "Production database empty - run pipeline"
    }


@router.get("/pipeline-progress")
async def get_pipeline_progress():
    """Get real-time pipeline execution progress"""
    return {
        "is_running": pipeline_progress["is_running"],
        "current_agent": pipeline_progress["current_agent"],
        "status": pipeline_progress["status"],
        "started_at": pipeline_progress["started_at"],
        "completed_at": pipeline_progress["completed_at"],
        "logs": pipeline_progress["logs"][-20:]
    }
