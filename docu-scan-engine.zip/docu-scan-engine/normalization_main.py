#!/usr/bin/env python3
"""
Normalization Agent Main Entry Point
Extracts ERD entities from documents with status 'Data Extracted'
"""

import os
import sys
import argparse
import logging
from pathlib import Path

from src.normalization_agent import NormalizationAgent

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """
    Main entry point for Normalization Agent
    """
    print("\n" + "=" * 60)
    print("NORMALIZATION AGENT - ENTITY EXTRACTION ENGINE")
    print("=" * 60)
    print("Intelligent entity extraction for formulation specs\n")
    
    parser = argparse.ArgumentParser(description='Normalization Agent - Entity Extraction')
    parser.add_argument('--limit', type=int, default=10, 
                       help='Maximum number of documents to process (default: 10)')
    
    args = parser.parse_args()
    
    database_url = os.getenv('DATABASE_URL')
    if not database_url:
        logger.error("DATABASE_URL environment variable not set")
        sys.exit(1)
    
    logger.info("✓ Database URL configured")
    
    try:
        agent = NormalizationAgent()
        
        summary = agent.run_normalization_workflow(limit=args.limit)
        
        logger.info(f"\n[NORMALIZATION AGENT] Workflow Summary:")
        logger.info(f"Status: {summary['status']}")
        logger.info(f"Documents processed: {summary.get('total_processed', 0)}")
        logger.info(f"Successfully normalized: {summary['normalized_count']}")
        logger.info(f"Failed: {summary['failed_count']}")
        
        logger.info(f"\n✓ Normalization workflow completed successfully")
        logger.info("Entities are now ready for Qualification Agent")
        
        return summary
        
    except Exception as e:
        logger.error(f"Normalization workflow failed: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
