# Google Drive OAuth Setup Guide

This guide will help you set up full read-only access to your Google Drive for the Connection Agent.

## Why Custom OAuth?

The default Replit Google Drive connector uses limited permissions (`drive.file` scope) that only allows access to files created by the app itself. To access your existing Google Drive folders like 'DigitisationEngineSource', you need custom OAuth credentials with broader permissions.

## Step-by-Step Setup

### Part 1: Create Google Cloud Project

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/
   - Sign in with your Google account

2. **Create a New Project**
   - Click the project dropdown at the top
   - Click "NEW PROJECT"
   - Name it: "Connection Agent" (or your preferred name)
   - Click "CREATE"
   - Wait for the project to be created, then select it

### Part 2: Enable Google Drive API

1. **Open APIs & Services**
   - From the left menu, click "APIs & Services" → "Library"
   
2. **Search for Drive API**
   - In the search box, type "Google Drive API"
   - Click on "Google Drive API" from the results
   
3. **Enable the API**
   - Click the blue "ENABLE" button
   - Wait for it to enable (takes a few seconds)

### Part 3: Configure OAuth Consent Screen

1. **Go to OAuth Consent Screen**
   - From the left menu, click "OAuth consent screen"
   
2. **Choose User Type**
   - Select "External" (unless you have a Google Workspace account)
   - Click "CREATE"
   
3. **Fill in App Information**
   - **App name**: Connection Agent
   - **User support email**: Your email address
   - **Developer contact email**: Your email address
   - Leave other fields as default
   - Click "SAVE AND CONTINUE"
   
4. **Add Scopes**
   - Click "ADD OR REMOVE SCOPES"
   - In the filter box, search for: `drive.readonly`
   - Check the box for: `https://www.googleapis.com/auth/drive.readonly`
   - This gives read-only access to all your Drive files
   - Click "UPDATE"
   - Click "SAVE AND CONTINUE"
   
5. **Add Test Users** (if app is not published)
   - Click "+ ADD USERS"
   - Enter your Google email address
   - Click "ADD"
   - Click "SAVE AND CONTINUE"
   
6. **Review and Finish**
   - Review the summary
   - Click "BACK TO DASHBOARD"

### Part 4: Create OAuth Credentials

1. **Go to Credentials**
   - From the left menu, click "Credentials"
   
2. **Create OAuth Client ID**
   - Click "+ CREATE CREDENTIALS" at the top
   - Select "OAuth client ID"
   
3. **Configure the Client**
   - **Application type**: Select "Desktop app"
   - **Name**: Connection Agent Desktop
   - Click "CREATE"
   
4. **Save Your Credentials**
   - A popup will show your Client ID and Client Secret
   - **IMPORTANT**: Copy both values and save them securely
   - You'll need these for the next step
   - Click "OK"

### Part 5: Configure Connection Agent

Now you have your credentials! You can configure the Connection Agent in two ways:

#### Option A: Using Replit Secrets (Recommended)

1. **Open Replit Secrets** (Tools → Secrets or the lock icon)

2. **Add these secrets**:
   ```
   GOOGLE_CLIENT_ID=your-client-id-here.apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=your-client-secret-here
   ```

3. **Run the setup**:
   ```bash
   CONNECTION_MODE=interactive python main.py
   ```
   - Choose option 2 (Google Drive)
   - Select "Custom OAuth credentials"
   - It will use your Replit Secrets automatically

#### Option B: Using Job Config File

1. **Run interactive setup**:
   ```bash
   CONNECTION_MODE=interactive python main.py
   ```

2. **Choose Google Drive setup**:
   - Select option 2 (Google Drive)
   - Choose "Custom OAuth credentials"
   - Enter your Client ID when prompted
   - Enter your Client Secret when prompted
   - Enter folder name: `DigitisationEngineSource`

3. **Configuration will be saved** to `job_config.json`

### Part 6: First-Time Authentication

1. **Run the Connection Agent**:
   ```bash
   python main.py
   ```

2. **Browser Authentication Flow**:
   - A URL will appear in the console
   - Copy the URL and paste it in your browser
   - Sign in with your Google account
   - Grant permissions when asked
   - You'll see an authorization code
   - Copy the code and paste it back into the console

3. **Authentication Complete**:
   - The agent will save your refresh token
   - Future runs won't require browser authentication
   - Your token is stored securely in `token.json`

## Security Notes

- **Client ID & Secret**: Store in Replit Secrets (encrypted)
- **Refresh Token**: Stored in `token.json` (add to `.gitignore`)
- **Scope**: `drive.readonly` gives read-only access (cannot modify/delete files)
- **Revoke Access**: You can revoke access anytime at https://myaccount.google.com/permissions

## Troubleshooting

### "Access blocked: This app's request is invalid"
- Make sure you added your email as a test user in the OAuth consent screen
- Make sure the Drive API is enabled

### "redirect_uri_mismatch"
- You're using "Desktop app" type, which doesn't need redirect URIs
- If you see this, recreate credentials as "Desktop app"

### "Invalid client secret"
- Double-check you copied the secret correctly
- No extra spaces or characters
- Try regenerating the secret in Google Cloud Console

### Can't see files from my Drive
- Verify the scope is `drive.readonly` (not `drive.file`)
- Complete the first-time authentication flow
- Check that the folder 'DigitisationEngineSource' exists in your Drive

## What's Next?

Once configured, the Connection Agent will:
- ✅ Connect to your Google Drive with read-only access
- ✅ Find the 'DigitisationEngineSource' folder
- ✅ Extract all documents (PDFs, Google Docs, etc.)
- ✅ Download files with metadata and keywords
- ✅ Export to JSON and CSV

Happy digitizing! 🚀
